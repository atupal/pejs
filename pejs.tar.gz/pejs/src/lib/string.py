def join(sequence):
  result = ""
  #unpack sequence
  for string in sequence:
    result = result + string
  return result