//This file was automatically created with compiler.py

var MethodCalls = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["i", "c", "o"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,90,0,1,100,0,2,90,0,2,101,0,1,105,0,3,131,0,0,1,101,0,1,105,0,4,101,0,2,101,0,2,131,0,2,1,101,0,1,105,0,4,101,0,2,100,0,3,131,0,2,1,101,0,1,105,0,4,100,0,3,100,0,3,131,0,2,1,101,0,1,105,0,5,101,0,2,101,0,2,131,0,2,1,101,0,1,105,0,5,101,0,2,100,0,3,131,0,2,1,101,0,1,105,0,5,101,0,2,100,0,3,100,0,2,131,0,3,1,101,0,1,105,0,5,101,0,2,101,0,2,100,0,0,100,0,4,131,0,258,1,100,0,5,71,72,100,0,6,83],
  co_consts: ["c", "CODEOBJ: MethodCalls_c", 3, 2, 4, 42, "None"],
  co_names: ["c", "o", "i", "f", "j", "k"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodCalls"}
};

var MethodCalls_c = {
  co_name: "c",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,90,0,3,100,0,3,132,0,0,90,0,4,100,0,4,132,0,0,90,0,5,100,0,5,100,0,6,132,0,1,90,0,6,82,83],
  co_consts: ["None", 2, "string", "CODEOBJ: MethodCalls_c_f", "CODEOBJ: MethodCalls_c_j", 3, "CODEOBJ: MethodCalls_c_k"],
  co_names: ["__name__", "__module__", "x", "s", "f", "j", "k"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodCalls_c"}
};

var MethodCalls_c_f = {
  co_name: "f",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [124,0,0,105,0,1,83],
  co_consts: ["None"],
  co_names: ["self", "x"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodCalls_c_f"}
};

var MethodCalls_c_j = {
  co_name: "j",
  co_argcount: 3,
  co_nlocals: 3,
  co_varnames: ["self", "a", "b"],
  co_code: [124,0,1,124,0,0,95,0,2,124,0,2,124,0,0,95,0,4,124,0,0,105,0,2,83],
  co_consts: ["None"],
  co_names: ["a", "self", "y", "b", "t"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodCalls_c_j"}
};

var MethodCalls_c_k = {
  co_name: "k",
  co_argcount: 4,
  co_nlocals: 4,
  co_varnames: ["self", "a", "b", "c"],
  co_code: [124,0,1,124,0,0,95,0,2,124,0,2,124,0,0,95,0,4,124,0,3,124,0,0,95,0,6,100,0,0,83],
  co_consts: ["None"],
  co_names: ["a", "self", "y", "b", "s", "c", "t"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodCalls_c_k"}
};

