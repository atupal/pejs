//This file was automatically created with compiler.py

var BenchmarkCallsRecursion = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["Recursion"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,131,0,0,1,100,0,2,71,72,100,0,3,83],
  co_consts: ["Recursion", "CODEOBJ: BenchmarkCallsRecursion_Recursion", 42, "None"],
  co_names: ["Recursion", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsRecursion"}
};

var BenchmarkCallsRecursion_Recursion = {
  co_name: "Recursion",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,90,0,3,100,0,3,90,0,4,100,0,4,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 5, 100, "CODEOBJ: BenchmarkCallsRecursion_Recursion_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsRecursion_Recursion"}
};

var BenchmarkCallsRecursion_Recursion_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 2,
  co_varnames: ["self", "i"],
  co_code: [100,0,1,132,0,0,97,0,0,120,0,73,116,0,1,124,0,0,105,0,3,131,0,1,68,93,0,56,125,0,1,116,0,0,100,0,2,131,0,1,1,116,0,0,100,0,2,131,0,1,1,116,0,0,100,0,2,131,0,1,1,116,0,0,100,0,2,131,0,1,1,116,0,0,100,0,2,131,0,1,1,113,0,25,87,100,0,0,83],
  co_consts: ["None", "CODEOBJ: BenchmarkCallsRecursion_Recursion_test_f", 10],
  co_names: ["f", "xrange", "self", "rounds", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsRecursion_Recursion_test"}
};

var BenchmarkCallsRecursion_Recursion_test_f = {
  co_name: "f",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["x"],
  co_code: [124,0,0,100,0,1,106,0,4,111,0,18,1,116,0,1,124,0,0,100,0,1,24,131,0,1,83,110,0,1,1,100,0,1,83],
  co_consts: ["None", 1],
  co_names: ["x", "f"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsRecursion_Recursion_test_f"}
};

