//This file was automatically created with compiler.py

var DefaultArgument2 = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["fun"],
  co_code: [100,0,0,100,0,1,100,0,2,132,0,2,90,0,0,101,0,0,100,0,3,131,0,1,101,0,0,100,0,4,100,0,5,131,0,2,23,101,0,0,100,0,6,100,0,7,100,0,8,131,0,3,23,71,72,100,0,9,83],
  co_consts: [10, 4, "CODEOBJ: DefaultArgument2_fun", 6, 3, 2, 5, 1, 7, "None"],
  co_names: ["fun"],
  co_locals: [],
  toString: function() { return "CodeObject:DefaultArgument2"}
};

var DefaultArgument2_fun = {
  co_name: "fun",
  co_argcount: 3,
  co_nlocals: 3,
  co_varnames: ["arg1", "arg2", "arg3"],
  co_code: [124,0,0,124,0,1,23,124,0,2,23,83],
  co_consts: ["None"],
  co_names: ["arg1", "arg2", "arg3"],
  co_locals: [],
  toString: function() { return "CodeObject:DefaultArgument2_fun"}
};

