//This file was automatically created with compiler.py

var FieldInheritance = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["Super", "Sub"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,100,0,2,101,0,0,102,0,1,100,0,3,132,0,0,131,0,0,89,90,0,1,101,0,1,131,0,0,105,0,2,101,0,1,131,0,0,105,0,3,23,71,72,100,0,4,83],
  co_consts: ["Super", "CODEOBJ: FieldInheritance_Super", "Sub", "CODEOBJ: FieldInheritance_Sub", "None"],
  co_names: ["Super", "Sub", "super1", "super2"],
  co_locals: [],
  toString: function() { return "CodeObject:FieldInheritance"}
};

var FieldInheritance_Super = {
  co_name: "Super",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,90,0,3,82,83],
  co_consts: ["None", 5, 10],
  co_names: ["__name__", "__module__", "super1", "super2"],
  co_locals: [],
  toString: function() { return "CodeObject:FieldInheritance_Super"}
};

var FieldInheritance_Sub = {
  co_name: "Sub",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,82,83],
  co_consts: ["None", 37],
  co_names: ["__name__", "__module__", "super2"],
  co_locals: [],
  toString: function() { return "CodeObject:FieldInheritance_Sub"}
};

