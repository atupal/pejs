//This file was automatically created with compiler.py

var TryExceptRaise = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [121,0,7,130,0,0,87,110,0,12,1,1,1,100,0,0,71,72,110,0,1,88,100,0,1,83],
  co_consts: [42, "None"],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:TryExceptRaise"}
};

