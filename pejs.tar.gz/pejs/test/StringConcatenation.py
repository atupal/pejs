print "4"+"2"
