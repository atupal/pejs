if True:
  a = 3
  b = 30
else:
  a = 200
  b = 123

if False:
  a = 100
  b = 234
else:
  a = a + 4
  b = b + 5

print a+b
