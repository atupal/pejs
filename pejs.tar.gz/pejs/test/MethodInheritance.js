//This file was automatically created with compiler.py

var MethodInheritance = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["Super", "Sub"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,100,0,2,101,0,0,102,0,1,100,0,3,132,0,0,131,0,0,89,90,0,1,101,0,1,131,0,0,105,0,2,131,0,0,101,0,1,131,0,0,105,0,3,131,0,0,23,71,72,100,0,4,83],
  co_consts: ["Super", "CODEOBJ: MethodInheritance_Super", "Sub", "CODEOBJ: MethodInheritance_Sub", "None"],
  co_names: ["Super", "Sub", "super1", "super2"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance"}
};

var MethodInheritance_Super = {
  co_name: "Super",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,132,0,0,90,0,2,100,0,2,132,0,0,90,0,3,82,83],
  co_consts: ["None", "CODEOBJ: MethodInheritance_Super_super1", "CODEOBJ: MethodInheritance_Super_super2"],
  co_names: ["__name__", "__module__", "super1", "super2"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance_Super"}
};

var MethodInheritance_Sub = {
  co_name: "Sub",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,132,0,0,90,0,2,82,83],
  co_consts: ["None", "CODEOBJ: MethodInheritance_Sub_super2"],
  co_names: ["__name__", "__module__", "super2"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance_Sub"}
};

var MethodInheritance_Super_super1 = {
  co_name: "super1",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 5],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance_Super_super1"}
};

var MethodInheritance_Super_super2 = {
  co_name: "super2",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 10],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance_Super_super2"}
};

var MethodInheritance_Sub_super2 = {
  co_name: "super2",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 37],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance_Sub_super2"}
};

