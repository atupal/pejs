//This file was automatically created with compiler.py

var ClassMethodInjection = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["MyObject", "obj", "b2", "a2"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,100,0,2,132,0,0,90,0,1,100,0,3,132,0,0,90,0,2,101,0,1,101,0,0,95,0,3,101,0,2,101,0,0,95,0,4,101,0,0,131,0,0,90,0,5,101,0,5,105,0,3,131,0,0,101,0,5,105,0,4,131,0,0,23,71,72,100,0,4,83],
  co_consts: ["MyObject", "CODEOBJ: ClassMethodInjection_MyObject", "CODEOBJ: ClassMethodInjection_a2", "CODEOBJ: ClassMethodInjection_b2", "None"],
  co_names: ["MyObject", "a2", "b2", "a", "b", "obj"],
  co_locals: [],
  toString: function() { return "CodeObject:ClassMethodInjection"}
};

var ClassMethodInjection_MyObject = {
  co_name: "MyObject",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,132,0,0,90,0,2,82,83],
  co_consts: ["None", "CODEOBJ: ClassMethodInjection_MyObject_a"],
  co_names: ["__name__", "__module__", "a"],
  co_locals: [],
  toString: function() { return "CodeObject:ClassMethodInjection_MyObject"}
};

var ClassMethodInjection_a2 = {
  co_name: "a2",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 20],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:ClassMethodInjection_a2"}
};

var ClassMethodInjection_b2 = {
  co_name: "b2",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 22],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:ClassMethodInjection_b2"}
};

var ClassMethodInjection_MyObject_a = {
  co_name: "a",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 100],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:ClassMethodInjection_MyObject_a"}
};

