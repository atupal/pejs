//This file was automatically created with compiler.py

var MethodCallsWithKWArgs = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["c", "result"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,100,0,2,100,0,3,131,0,2,90,0,2,101,0,2,101,0,0,131,0,0,105,0,1,100,0,4,100,0,5,100,0,6,131,0,3,23,90,0,2,101,0,2,101,0,0,131,0,0,105,0,1,100,0,7,100,0,8,100,0,0,100,0,9,131,0,258,23,90,0,2,101,0,2,101,0,0,131,0,0,105,0,1,100,0,10,100,0,11,100,0,0,100,0,6,100,0,12,100,0,7,131,0,768,23,90,0,2,101,0,2,101,0,0,131,0,0,105,0,1,100,0,10,100,0,7,100,0,12,100,0,2,131,0,512,23,90,0,2,101,0,2,71,72,100,0,13,83],
  co_consts: ["c", "CODEOBJ: MethodCallsWithKWArgs_c", 4, 9, 1, 17, 8, 2, 14, 6, "b", 15, "a", "None"],
  co_names: ["c", "m", "result"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodCallsWithKWArgs"}
};

var MethodCallsWithKWArgs_c = {
  co_name: "c",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,100,0,2,132,0,1,90,0,2,82,83],
  co_consts: ["None", 3, "CODEOBJ: MethodCallsWithKWArgs_c_m"],
  co_names: ["__name__", "__module__", "m"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodCallsWithKWArgs_c"}
};

var MethodCallsWithKWArgs_c_m = {
  co_name: "m",
  co_argcount: 4,
  co_nlocals: 4,
  co_varnames: ["self", "a", "b", "c"],
  co_code: [124,0,1,124,0,2,23,124,0,3,24,83],
  co_consts: ["None"],
  co_names: ["a", "b", "c"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodCallsWithKWArgs_c_m"}
};

