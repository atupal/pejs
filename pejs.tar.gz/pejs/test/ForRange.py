j = 0
for i in range(5,47):
  j = j + 1
print j
