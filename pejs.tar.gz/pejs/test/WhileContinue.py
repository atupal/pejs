i = 0
while True:
  i = i + 1
  if i > 41:
    break
  continue
  i = 100
print i