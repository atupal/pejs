i = 0

if i == 0:
  i = i + 1
elif i == 1:
  i = i + 100
else:
  i = i + 100
  
if i == 0:
  i = i + 100
elif i == 1:
  i = i + 1
else:
  i = i + 100
  
if i == 0:
  i = i + 100
elif i == 1:
  i = i + 100
else:
  i = i + 1
  
print i + 39