a = 0
b = 0
while a < 2:
  a = a + 1
  for l in range(0,2):
    b = b + 1
    
#a = 10
#b = 100

print b * 10 + a