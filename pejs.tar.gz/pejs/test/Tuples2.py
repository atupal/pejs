a = (1,30,11)
a = list(a)
b = tuple(a)
print b[0] + b[1] + b[2]