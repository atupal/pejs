result = 0

for i in xrange(10):
  result = result + 2
  
for i in xrange(5,17):
  result = result + 1
  
for i in xrange(10,30,2):
  result = result + 1
  
print result