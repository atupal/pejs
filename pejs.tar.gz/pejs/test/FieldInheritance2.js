//This file was automatically created with compiler.py

var FieldInheritance2 = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["Sub", "Super1", "Super0", "Super2"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,100,0,2,101,0,0,102,0,1,100,0,3,132,0,0,131,0,0,89,90,0,1,100,0,4,102,0,0,100,0,5,132,0,0,131,0,0,89,90,0,2,100,0,6,101,0,1,101,0,2,102,0,2,100,0,7,132,0,0,131,0,0,89,90,0,3,101,0,3,131,0,0,105,0,4,101,0,3,131,0,0,105,0,5,23,101,0,3,131,0,0,105,0,6,23,71,72,100,0,8,83],
  co_consts: ["Super0", "CODEOBJ: FieldInheritance2_Super0", "Super1", "CODEOBJ: FieldInheritance2_Super1", "Super2", "CODEOBJ: FieldInheritance2_Super2", "Sub", "CODEOBJ: FieldInheritance2_Sub", "None"],
  co_names: ["Super0", "Super1", "Super2", "Sub", "field0", "field1", "field3"],
  co_locals: [],
  toString: function() { return "CodeObject:FieldInheritance2"}
};

var FieldInheritance2_Super0 = {
  co_name: "Super0",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,90,0,3,100,0,3,90,0,4,82,83],
  co_consts: ["None", 8, 4000, 109],
  co_names: ["__name__", "__module__", "field0", "field1", "field2"],
  co_locals: [],
  toString: function() { return "CodeObject:FieldInheritance2_Super0"}
};

var FieldInheritance2_Super1 = {
  co_name: "Super1",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,82,83],
  co_consts: ["None", 18],
  co_names: ["__name__", "__module__", "field1"],
  co_locals: [],
  toString: function() { return "CodeObject:FieldInheritance2_Super1"}
};

var FieldInheritance2_Super2 = {
  co_name: "Super2",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,90,0,3,100,0,3,90,0,4,100,0,4,90,0,5,82,83],
  co_consts: ["None", 100, 300, 3000, 16],
  co_names: ["__name__", "__module__", "field0", "field1", "field2", "field3"],
  co_locals: [],
  toString: function() { return "CodeObject:FieldInheritance2_Super2"}
};

var FieldInheritance2_Sub = {
  co_name: "Sub",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,82,83],
  co_consts: ["None"],
  co_names: ["__name__", "__module__"],
  co_locals: [],
  toString: function() { return "CodeObject:FieldInheritance2_Sub"}
};

