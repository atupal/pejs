//This file was automatically created with compiler.py

var BenchmarkListsListSlicing = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["ListSlicing"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,131,0,0,1,100,0,2,71,72,100,0,3,83],
  co_consts: ["ListSlicing", "CODEOBJ: BenchmarkListsListSlicing_ListSlicing", 42, "None"],
  co_names: ["ListSlicing", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkListsListSlicing"}
};

var BenchmarkListsListSlicing_ListSlicing = {
  co_name: "ListSlicing",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,100,0,3,100,0,4,23,100,0,5,23,100,0,4,23,20,90,0,3,100,0,6,90,0,4,100,0,7,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 25, 3, 1, 2, 80, "CODEOBJ: BenchmarkListsListSlicing_ListSlicing_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkListsListSlicing_ListSlicing"}
};

var BenchmarkListsListSlicing_ListSlicing_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 7,
  co_varnames: ["self", "i", "j", "m", "l", "n", "r"],
  co_code: [116,0,0,100,0,1,131,0,1,125,0,5,116,0,0,100,0,2,131,0,1,125,0,6,120,0,120,116,0,3,124,0,0,105,0,5,131,0,1,68,93,0,103,125,0,1,124,0,5,30,125,0,4,120,0,87,124,0,6,68,93,0,79,125,0,2,124,0,4,100,0,3,31,125,0,3,124,0,4,100,0,2,32,125,0,3,124,0,4,100,0,3,100,0,4,33,125,0,3,124,0,5,124,0,4,100,0,5,42,124,0,4,100,0,6,32,125,0,3,124,0,4,100,0,7,31,125,0,3,124,0,5,124,0,4,100,0,6,41,113,0,60,87,113,0,40,87,100,0,0,83],
  co_consts: ["None", 100, 25, 50, 55, 3, -1, 1],
  co_names: ["range", "n", "r", "xrange", "self", "rounds", "i", "l", "j", "m"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkListsListSlicing_ListSlicing_test"}
};

