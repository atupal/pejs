#First import:
import package

class SecondPackageImport:

    version = 2.0
    operations = 5 * 5
    rounds = 4#0000

    def test(self):

        for i in xrange(self.rounds):
            import package
            import package
            import package
            import package
            import package

            import package
            import package
            import package
            import package
            import package

            import package
            import package
            import package
            import package
            import package

            import package
            import package
            import package
            import package
            import package

            import package
            import package
            import package
            import package
            import package

SecondPackageImport().test()

print 42