//This file was automatically created with compiler.py

var Recursion3 = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["rec"],
  co_code: [100,0,0,132,0,0,90,0,0,101,0,0,100,0,1,131,0,1,100,0,2,23,71,72,100,0,3,83],
  co_consts: ["CODEOBJ: Recursion3_rec", 5, 10, "None"],
  co_names: ["rec"],
  co_locals: [],
  toString: function() { return "CodeObject:Recursion3"}
};

var Recursion3_rec = {
  co_name: "rec",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["n"],
  co_code: [124,0,0,100,0,1,106,0,2,111,0,8,1,100,0,2,83,110,0,29,1,116,0,1,124,0,0,100,0,2,24,131,0,1,116,0,1,124,0,0,100,0,2,24,131,0,1,23,83,100,0,0,83],
  co_consts: ["None", 0, 1],
  co_names: ["n", "rec"],
  co_locals: [],
  toString: function() { return "CodeObject:Recursion3_rec"}
};

