//This file was automatically created with compiler.py

var Pass = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["a", "i"],
  co_code: [100,0,0,90,0,0,120,0,40,101,0,1,100,0,1,131,0,1,68,93,0,26,90,0,2,101,0,0,100,0,2,23,90,0,0,101,0,0,100,0,2,23,90,0,0,113,0,19,87,101,0,0,71,72,100,0,3,83],
  co_consts: [30, 6, 1, "None"],
  co_names: ["a", "xrange", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:Pass"}
};

