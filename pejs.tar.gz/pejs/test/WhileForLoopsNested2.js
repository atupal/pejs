//This file was automatically created with compiler.py

var WhileForLoopsNested2 = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["a", "i", "b", "k"],
  co_code: [100,0,0,90,0,0,100,0,0,90,0,1,120,0,80,101,0,2,100,0,0,100,0,1,131,0,2,68,93,0,63,90,0,3,101,0,0,100,0,2,23,90,0,0,100,0,0,90,0,4,120,0,38,101,0,4,100,0,1,106,0,0,111,0,24,1,101,0,1,100,0,2,23,90,0,1,101,0,4,100,0,2,23,90,0,4,113,0,53,1,87,113,0,28,87,101,0,1,100,0,3,101,0,0,20,24,100,0,4,24,71,72,100,0,5,83],
  co_consts: [0, 10, 1, 5, 8, "None"],
  co_names: ["a", "b", "range", "i", "k"],
  co_locals: [],
  toString: function() { return "CodeObject:WhileForLoopsNested2"}
};

