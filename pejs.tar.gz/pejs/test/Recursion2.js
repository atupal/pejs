//This file was automatically created with compiler.py

var Recursion2 = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["rec2", "rec1", "one"],
  co_code: [100,0,0,132,0,0,90,0,0,100,0,1,132,0,0,90,0,1,100,0,2,132,0,0,90,0,2,101,0,0,100,0,3,131,0,1,71,72,100,0,4,83],
  co_consts: ["CODEOBJ: Recursion2_rec1", "CODEOBJ: Recursion2_rec2", "CODEOBJ: Recursion2_one", 20, "None"],
  co_names: ["rec1", "rec2", "one"],
  co_locals: [],
  toString: function() { return "CodeObject:Recursion2"}
};

var Recursion2_rec1 = {
  co_name: "rec1",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["n"],
  co_code: [124,0,0,100,0,1,106,0,2,111,0,8,1,100,0,2,83,110,0,25,1,116,0,1,100,0,2,131,0,1,116,0,2,124,0,0,100,0,3,24,131,0,1,23,83,100,0,0,83],
  co_consts: ["None", 0, 2, 1],
  co_names: ["n", "rec2", "rec1"],
  co_locals: [],
  toString: function() { return "CodeObject:Recursion2_rec1"}
};

var Recursion2_rec2 = {
  co_name: "rec2",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["n"],
  co_code: [124,0,0,100,0,1,106,0,2,111,0,8,1,100,0,1,83,110,0,22,1,116,0,1,131,0,0,116,0,2,124,0,0,100,0,2,24,131,0,1,23,83,100,0,0,83],
  co_consts: ["None", 0, 1],
  co_names: ["n", "one", "rec2"],
  co_locals: [],
  toString: function() { return "CodeObject:Recursion2_rec2"}
};

var Recursion2_one = {
  co_name: "one",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,1,83],
  co_consts: ["None", 1],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:Recursion2_one"}
};

