a = 0
b = 0
c = 0
for i in range(0,10):
  a = a + 1
  k = 0
  while k < 10:
   b = b + 1
   k = k + 1
   for l in range(0,10):
    c = c + 1
    
#a = 10
#b = 100
#c = 1000
print c - 9*b - 5*a - 8