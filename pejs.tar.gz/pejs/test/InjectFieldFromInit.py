class MyClass:
  c = 1000
  d = 7
  def __init__(self,a,b,c):
      self.a = a
      self.b = b
      self.c = c

obj = MyClass(1,14,20)

print obj.a + obj.b + obj.c + obj.d