//This file was automatically created with compiler.py

var DefaultArgument = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["fun"],
  co_code: [100,0,0,100,0,1,100,0,2,132,0,2,90,0,0,101,0,0,131,0,0,101,0,0,100,0,3,131,0,1,23,101,0,0,100,0,4,100,0,5,131,0,2,23,71,72,100,0,6,83],
  co_consts: [10, 4, "CODEOBJ: DefaultArgument_fun", 1, 14, 9, "None"],
  co_names: ["fun"],
  co_locals: [],
  toString: function() { return "CodeObject:DefaultArgument"}
};

var DefaultArgument_fun = {
  co_name: "fun",
  co_argcount: 2,
  co_nlocals: 2,
  co_varnames: ["arg1", "arg2"],
  co_code: [124,0,0,124,0,1,23,83],
  co_consts: ["None"],
  co_names: ["arg1", "arg2"],
  co_locals: [],
  toString: function() { return "CodeObject:DefaultArgument_fun"}
};

