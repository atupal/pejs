//This file was automatically created with compiler.py

var BenchmarkStringsConcatStrings = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["join", "ConcatStrings"],
  co_code: [100,0,0,107,0,0,108,0,1,90,0,1,1,100,0,1,102,0,0,100,0,2,132,0,0,131,0,0,89,90,0,2,101,0,2,131,0,0,105,0,3,131,0,0,1,100,0,3,71,72,100,0,4,83],
  co_consts: [["join"], "ConcatStrings", "CODEOBJ: BenchmarkStringsConcatStrings_ConcatStrings", 42, "None"],
  co_names: ["string", "join", "ConcatStrings", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkStringsConcatStrings"}
};

var BenchmarkStringsConcatStrings_ConcatStrings = {
  co_name: "ConcatStrings",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,100,0,3,20,90,0,3,100,0,4,90,0,4,100,0,5,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 10, 5, 1000, "CODEOBJ: BenchmarkStringsConcatStrings_ConcatStrings_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkStringsConcatStrings_ConcatStrings"}
};

var BenchmarkStringsConcatStrings_ConcatStrings_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 4,
  co_varnames: ["self", "i", "s", "t"],
  co_code: [116,0,0,116,0,1,116,0,2,116,0,3,100,0,1,131,0,1,131,0,2,131,0,1,125,0,2,116,0,0,116,0,1,116,0,2,116,0,3,100,0,2,100,0,3,131,0,2,131,0,2,131,0,1,125,0,3,120,0,423,116,0,6,124,0,0,105,0,8,131,0,1,68,93,0,406,125,0,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,124,0,3,124,0,2,23,1,113,0,73,87,100,0,0,83],
  co_consts: ["None", 100, 1, 101],
  co_names: ["join", "map", "str", "range", "s", "t", "xrange", "self", "rounds", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkStringsConcatStrings_ConcatStrings_test"}
};

