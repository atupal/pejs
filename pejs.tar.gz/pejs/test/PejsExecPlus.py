exec "40+2" in "JavaScript", "variable"
print variable