//This file was automatically created with compiler.py

var PejsExecPrintStatement = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,0,100,0,1,4,85,100,0,2,83],
  co_consts: ["PEJS.prototype.printOut(42);", "JavaScript", "None"],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:PejsExecPrintStatement"}
};

