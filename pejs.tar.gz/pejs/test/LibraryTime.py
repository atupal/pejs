import time

stamp = time.time()

if stamp > 1227536929:
  print 42
else:
  print "timestamp was: "+str(stamp)