//This file was automatically created with compiler.py

var Range = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["l"],
  co_code: [101,0,0,100,0,0,131,0,1,90,0,1,101,0,1,100,0,1,25,101,0,1,100,0,2,25,23,101,0,1,100,0,3,25,23,101,0,1,100,0,4,25,23,101,0,1,100,0,5,25,23,101,0,1,100,0,6,25,23,101,0,1,100,0,7,25,23,101,0,1,100,0,8,25,23,101,0,1,100,0,9,25,23,101,0,1,100,0,7,25,23,71,72,100,0,10,83],
  co_consts: [20, 0, 1, 2, 3, 4, 5, 6, 7, 8, "None"],
  co_names: ["range", "l"],
  co_locals: [],
  toString: function() { return "CodeObject:Range"}
};

