//This file was automatically created with compiler.py

var StringConcatenation = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,0,100,0,1,23,71,72,100,0,2,83],
  co_consts: ["4", "2", "None"],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:StringConcatenation"}
};

