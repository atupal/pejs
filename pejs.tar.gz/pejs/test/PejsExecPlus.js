//This file was automatically created with compiler.py

var PejsExecPlus = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,0,100,0,1,100,0,2,85,101,0,0,71,72,100,0,3,83],
  co_consts: ["40+2", "JavaScript", "variable", "None"],
  co_names: ["variable"],
  co_locals: [],
  toString: function() { return "CodeObject:PejsExecPlus"}
};

