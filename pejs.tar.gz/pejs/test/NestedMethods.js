//This file was automatically created with compiler.py

var NestedMethods = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["Test"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,131,0,0,71,72,100,0,2,83],
  co_consts: ["Test", "CODEOBJ: NestedMethods_Test", "None"],
  co_names: ["Test", "a"],
  co_locals: [],
  toString: function() { return "CodeObject:NestedMethods"}
};

var NestedMethods_Test = {
  co_name: "Test",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,132,0,0,90,0,2,82,83],
  co_consts: ["None", "CODEOBJ: NestedMethods_Test_a"],
  co_names: ["__name__", "__module__", "a"],
  co_locals: [],
  toString: function() { return "CodeObject:NestedMethods_Test"}
};

var NestedMethods_Test_a = {
  co_name: "a",
  co_argcount: 1,
  co_nlocals: 3,
  co_varnames: ["self", "i", "b"],
  co_code: [100,0,1,125,0,1,100,0,2,132,0,0,125,0,2,124,0,2,131,0,0,124,0,1,23,83],
  co_consts: ["None", 11, "CODEOBJ: NestedMethods_Test_a_b"],
  co_names: ["i", "b"],
  co_locals: [],
  toString: function() { return "CodeObject:NestedMethods_Test_a"}
};

var NestedMethods_Test_a_b = {
  co_name: "b",
  co_argcount: 0,
  co_nlocals: 1,
  co_varnames: ["c"],
  co_code: [100,0,1,132,0,0,125,0,0,100,0,2,124,0,0,131,0,0,23,83],
  co_consts: ["None", "CODEOBJ: NestedMethods_Test_a_b_c", 8],
  co_names: ["c"],
  co_locals: [],
  toString: function() { return "CodeObject:NestedMethods_Test_a_b"}
};

var NestedMethods_Test_a_b_c = {
  co_name: "c",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,1,83],
  co_consts: ["None", 23],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:NestedMethods_Test_a_b_c"}
};

