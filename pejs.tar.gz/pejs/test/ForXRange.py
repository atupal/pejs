j = 0
for i in xrange(5,47):
  j = j + 1
print j
