def fun(n):
  n = 100
i = 42
fun(i)
print i
