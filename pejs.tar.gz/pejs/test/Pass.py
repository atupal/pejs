
a = 30
for i in xrange(6):
  a = a + 1
  pass
  a = a + 1
  
print a