class MyClass:
  myField = 5

MyClass.x = 17
MyClass.y = 1000
MyClass.y = 20

print MyClass.x + MyClass.y + MyClass.myField
