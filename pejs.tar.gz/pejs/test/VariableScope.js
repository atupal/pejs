//This file was automatically created with compiler.py

var VariableScope = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["y", "fun1", "fun2"],
  co_code: [100,0,0,97,0,0,100,0,1,90,0,1,100,0,2,132,0,0,90,0,2,100,0,3,132,0,0,90,0,3,101,0,2,131,0,0,1,116,0,0,116,0,0,23,101,0,1,23,101,0,1,23,100,0,4,23,71,72,100,0,5,83],
  co_consts: [100, 10, "CODEOBJ: VariableScope_fun1", "CODEOBJ: VariableScope_fun2", 2, "None"],
  co_names: ["x", "y", "fun1", "fun2"],
  co_locals: [],
  toString: function() { return "CodeObject:VariableScope"}
};

var VariableScope_fun1 = {
  co_name: "fun1",
  co_argcount: 0,
  co_nlocals: 1,
  co_varnames: ["z"],
  co_code: [116,0,0,100,0,1,24,97,0,0,100,0,2,125,0,0,100,0,0,83],
  co_consts: ["None", 90, 100],
  co_names: ["x", "z"],
  co_locals: [],
  toString: function() { return "CodeObject:VariableScope_fun1"}
};

var VariableScope_fun2 = {
  co_name: "fun2",
  co_argcount: 0,
  co_nlocals: 2,
  co_varnames: ["y", "z"],
  co_code: [100,0,1,125,0,0,100,0,2,125,0,1,100,0,0,83],
  co_consts: ["None", 100, 123],
  co_names: ["y", "z"],
  co_locals: [],
  toString: function() { return "CodeObject:VariableScope_fun2"}
};

