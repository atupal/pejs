//This file was automatically created with compiler.py

var Variables = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["four", "three", "two", "one"],
  co_code: [100,0,0,90,0,0,101,0,0,100,0,1,20,90,0,1,101,0,0,101,0,1,23,90,0,2,101,0,2,101,0,1,23,101,0,0,24,90,0,3,101,0,3,101,0,1,23,100,0,2,23,71,72,100,0,3,83],
  co_consts: [1, 2, 36, "None"],
  co_names: ["one", "two", "three", "four"],
  co_locals: [],
  toString: function() { return "CodeObject:Variables"}
};

