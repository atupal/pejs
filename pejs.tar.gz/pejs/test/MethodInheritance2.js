//This file was automatically created with compiler.py

var MethodInheritance2 = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["Sub", "Super1", "Super0", "Super2"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,100,0,2,101,0,0,102,0,1,100,0,3,132,0,0,131,0,0,89,90,0,1,100,0,4,102,0,0,100,0,5,132,0,0,131,0,0,89,90,0,2,100,0,6,101,0,1,101,0,2,102,0,2,100,0,7,132,0,0,131,0,0,89,90,0,3,101,0,3,131,0,0,105,0,4,131,0,0,101,0,3,131,0,0,105,0,5,131,0,0,23,101,0,3,131,0,0,105,0,6,131,0,0,23,71,72,100,0,8,83],
  co_consts: ["Super0", "CODEOBJ: MethodInheritance2_Super0", "Super1", "CODEOBJ: MethodInheritance2_Super1", "Super2", "CODEOBJ: MethodInheritance2_Super2", "Sub", "CODEOBJ: MethodInheritance2_Sub", "None"],
  co_names: ["Super0", "Super1", "Super2", "Sub", "super1", "super2", "super3"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2"}
};

var MethodInheritance2_Super0 = {
  co_name: "Super0",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,132,0,0,90,0,2,100,0,2,132,0,0,90,0,3,82,83],
  co_consts: ["None", "CODEOBJ: MethodInheritance2_Super0_super1", "CODEOBJ: MethodInheritance2_Super0_super2"],
  co_names: ["__name__", "__module__", "super1", "super2"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2_Super0"}
};

var MethodInheritance2_Super1 = {
  co_name: "Super1",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,132,0,0,90,0,2,82,83],
  co_consts: ["None", "CODEOBJ: MethodInheritance2_Super1_super2"],
  co_names: ["__name__", "__module__", "super2"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2_Super1"}
};

var MethodInheritance2_Super2 = {
  co_name: "Super2",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,132,0,0,90,0,2,100,0,2,132,0,0,90,0,3,100,0,3,132,0,0,90,0,4,82,83],
  co_consts: ["None", "CODEOBJ: MethodInheritance2_Super2_super1", "CODEOBJ: MethodInheritance2_Super2_super2", "CODEOBJ: MethodInheritance2_Super2_super3"],
  co_names: ["__name__", "__module__", "super1", "super2", "super3"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2_Super2"}
};

var MethodInheritance2_Sub = {
  co_name: "Sub",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,82,83],
  co_consts: ["None"],
  co_names: ["__name__", "__module__"],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2_Sub"}
};

var MethodInheritance2_Super0_super1 = {
  co_name: "super1",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 10],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2_Super0_super1"}
};

var MethodInheritance2_Super0_super2 = {
  co_name: "super2",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 500],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2_Super0_super2"}
};

var MethodInheritance2_Super1_super2 = {
  co_name: "super2",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 12],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2_Super1_super2"}
};

var MethodInheritance2_Super2_super1 = {
  co_name: "super1",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 800],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2_Super2_super1"}
};

var MethodInheritance2_Super2_super2 = {
  co_name: "super2",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 1200],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2_Super2_super2"}
};

var MethodInheritance2_Super2_super3 = {
  co_name: "super3",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 20],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:MethodInheritance2_Super2_super3"}
};

