//This file was automatically created with compiler.py

var ObjectMethodInjection = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["obj1", "obj2", "MyObject", "b2", "a2"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,100,0,2,132,0,0,90,0,1,100,0,3,132,0,0,90,0,2,101,0,0,131,0,0,90,0,3,101,0,0,131,0,0,90,0,4,101,0,1,101,0,3,95,0,5,101,0,2,101,0,3,95,0,6,101,0,4,105,0,5,131,0,0,100,0,4,106,0,3,111,0,9,1,100,0,5,71,72,110,0,1,1,101,0,3,105,0,5,131,0,0,101,0,3,105,0,6,131,0,0,23,71,72,100,0,6,83],
  co_consts: ["MyObject", "CODEOBJ: ObjectMethodInjection_MyObject", "CODEOBJ: ObjectMethodInjection_a2", "CODEOBJ: ObjectMethodInjection_b2", 100, 123, "None"],
  co_names: ["MyObject", "a2", "b2", "obj1", "obj2", "a", "b"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectMethodInjection"}
};

var ObjectMethodInjection_MyObject = {
  co_name: "MyObject",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,132,0,0,90,0,2,82,83],
  co_consts: ["None", "CODEOBJ: ObjectMethodInjection_MyObject_a"],
  co_names: ["__name__", "__module__", "a"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectMethodInjection_MyObject"}
};

var ObjectMethodInjection_a2 = {
  co_name: "a2",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,1,83],
  co_consts: ["None", 20],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectMethodInjection_a2"}
};

var ObjectMethodInjection_b2 = {
  co_name: "b2",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,1,83],
  co_consts: ["None", 22],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectMethodInjection_b2"}
};

var ObjectMethodInjection_MyObject_a = {
  co_name: "a",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", 100],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectMethodInjection_MyObject_a"}
};

