#!/bin/bash

rm -rf test/*.pyc
rm -rf test/*.js
rm -rf test/*~
rm -rf test/unsupported/*~
rm -rf src/*~
rm -rf src/lib/*.pyc
rm -rf src/lib/*.js
rm -rf src/lib/*~
rm -rf tools/*.pyc
rm -rf tools/*~
