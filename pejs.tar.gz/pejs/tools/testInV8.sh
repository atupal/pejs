#!/bin/bash
tools/prepareStandalone.sh
v8/shell test/standalone.js 