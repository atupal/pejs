//This file was automatically created with compiler.py

var ListIterator = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["i", "list", "result"],
  co_code: [100,0,0,100,0,1,100,0,2,100,0,3,100,0,4,100,0,5,100,0,6,100,0,7,100,0,8,100,0,9,100,0,10,100,0,11,100,0,12,100,0,13,100,0,14,100,0,15,100,0,16,100,0,17,100,0,18,103,0,19,90,0,0,100,0,19,90,0,1,120,0,24,101,0,0,68,93,0,16,90,0,2,101,0,1,101,0,2,23,90,0,1,113,0,76,87,101,0,1,71,72,100,0,20,83],
  co_consts: [3, 4, 5, 6, -7, 8, 9, -10, -11, 12, 13, 14, 15, -16, 17, -18, 19, -20, -1, 0, "None"],
  co_names: ["list", "result", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:ListIterator"}
};

