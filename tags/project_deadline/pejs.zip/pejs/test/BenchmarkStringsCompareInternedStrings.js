//This file was automatically created with compiler.py

var BenchmarkStringsCompareInternedStrings = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["join", "CompareInternedStrings"],
  co_code: [100,0,0,107,0,0,108,0,1,90,0,1,1,100,0,1,102,0,0,100,0,2,132,0,0,131,0,0,89,90,0,2,101,0,2,131,0,0,105,0,3,131,0,0,1,100,0,3,71,72,100,0,4,83],
  co_consts: [["join"], "CompareInternedStrings", "CODEOBJ: BenchmarkStringsCompareInternedStrings_CompareInternedStrings", 42, "None"],
  co_names: ["string", "join", "CompareInternedStrings", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkStringsCompareInternedStrings"}
};

var BenchmarkStringsCompareInternedStrings_CompareInternedStrings = {
  co_name: "CompareInternedStrings",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,100,0,3,20,90,0,3,100,0,4,90,0,4,100,0,5,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 10, 5, 300, "CODEOBJ: BenchmarkStringsCompareInternedStrings_CompareInternedStrings_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkStringsCompareInternedStrings_CompareInternedStrings"}
};

var BenchmarkStringsCompareInternedStrings_CompareInternedStrings_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 4,
  co_varnames: ["self", "i", "s", "t"],
  co_code: [116,0,0,116,0,1,116,0,2,116,0,3,116,0,4,100,0,1,131,0,1,131,0,2,131,0,1,131,0,1,125,0,2,124,0,2,125,0,3,120,0,523,116,0,7,124,0,0,105,0,9,131,0,1,68,93,0,506,125,0,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,5,1,124,0,3,124,0,2,106,0,4,1,124,0,3,124,0,2,106,0,0,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,5,1,124,0,3,124,0,2,106,0,4,1,124,0,3,124,0,2,106,0,0,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,5,1,124,0,3,124,0,2,106,0,4,1,124,0,3,124,0,2,106,0,0,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,5,1,124,0,3,124,0,2,106,0,4,1,124,0,3,124,0,2,106,0,0,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,5,1,124,0,3,124,0,2,106,0,4,1,124,0,3,124,0,2,106,0,0,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,5,1,124,0,3,124,0,2,106,0,4,1,124,0,3,124,0,2,106,0,0,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,5,1,124,0,3,124,0,2,106,0,4,1,124,0,3,124,0,2,106,0,0,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,5,1,124,0,3,124,0,2,106,0,4,1,124,0,3,124,0,2,106,0,0,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,5,1,124,0,3,124,0,2,106,0,4,1,124,0,3,124,0,2,106,0,0,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,2,1,124,0,3,124,0,2,106,0,5,1,124,0,3,124,0,2,106,0,4,1,124,0,3,124,0,2,106,0,0,1,113,0,55,87,100,0,0,83],
  co_consts: ["None", 10],
  co_names: ["intern", "join", "map", "str", "range", "s", "t", "xrange", "self", "rounds", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkStringsCompareInternedStrings_CompareInternedStrings_test"}
};

