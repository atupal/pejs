//This file was automatically created with compiler.py

var NestedFunctions = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["a"],
  co_code: [100,0,0,132,0,0,90,0,0,101,0,0,131,0,0,71,72,100,0,1,83],
  co_consts: ["CODEOBJ: NestedFunctions_a", "None"],
  co_names: ["a"],
  co_locals: [],
  toString: function() { return "CodeObject:NestedFunctions"}
};

var NestedFunctions_a = {
  co_name: "a",
  co_argcount: 0,
  co_nlocals: 2,
  co_varnames: ["i", "b"],
  co_code: [100,0,1,125,0,0,100,0,2,132,0,0,125,0,1,124,0,1,131,0,0,124,0,0,23,83],
  co_consts: ["None", 11, "CODEOBJ: NestedFunctions_a_b"],
  co_names: ["i", "b"],
  co_locals: [],
  toString: function() { return "CodeObject:NestedFunctions_a"}
};

var NestedFunctions_a_b = {
  co_name: "b",
  co_argcount: 0,
  co_nlocals: 1,
  co_varnames: ["c"],
  co_code: [100,0,1,132,0,0,125,0,0,100,0,2,124,0,0,131,0,0,23,83],
  co_consts: ["None", "CODEOBJ: NestedFunctions_a_b_c", 8],
  co_names: ["c"],
  co_locals: [],
  toString: function() { return "CodeObject:NestedFunctions_a_b"}
};

var NestedFunctions_a_b_c = {
  co_name: "c",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,1,83],
  co_consts: ["None", 23],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:NestedFunctions_a_b_c"}
};

