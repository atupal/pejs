class ForLoops:

    version = 2.0
    operations = 5 * 5
    rounds = 10#000

    def test(self):

        l1 = range(100)
        for i in xrange(self.rounds):
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass

            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass

            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass

            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass

            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass
            for i in l1:
                pass

ForLoops().test()
print 42