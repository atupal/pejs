def fun(arg1, arg2=10, arg3=4):
  return arg1 + arg2 + arg3
  
print fun(6) + fun(3,2) + fun(5,1,7)