class IfThenElse:

    version = 2.0
    operations = 30*3 # hard to say...
    rounds = 150#00

    def test(self):

        a,b,c = 1,2,3
        for i in xrange(self.rounds):

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

            if a == 1:
                if b == 2:
                    if c != 3:
                        c = 3
                        b = 3
                    else:
                        c = 2
                elif b == 3:
                    b = 2
                    a = 2
            elif a == 2:
                a = 3
            else:
                a = 1

    def calibrate(self):

        a,b,c = 1,2,3
        for i in xrange(self.rounds):
            pass
        
IfThenElse().test()

print 42