//This file was automatically created with compiler.py

var Conditional = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["a", "b"],
  co_code: [101,0,0,111,0,16,1,100,0,0,90,0,1,100,0,1,90,0,2,110,0,13,1,100,0,2,90,0,1,100,0,3,90,0,2,101,0,3,111,0,16,1,100,0,4,90,0,1,100,0,5,90,0,2,110,0,21,1,101,0,1,100,0,6,23,90,0,1,101,0,2,100,0,7,23,90,0,2,101,0,1,101,0,2,23,71,72,100,0,8,83],
  co_consts: [3, 30, 200, 123, 100, 234, 4, 5, "None"],
  co_names: ["True", "a", "b", "False"],
  co_locals: [],
  toString: function() { return "CodeObject:Conditional"}
};

