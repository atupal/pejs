//This file was automatically created with compiler.py

var InjectFieldFromInit = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["MyClass", "obj"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,100,0,2,100,0,3,100,0,4,131,0,3,90,0,1,101,0,1,105,0,2,101,0,1,105,0,3,23,101,0,1,105,0,4,23,101,0,1,105,0,5,23,71,72,100,0,5,83],
  co_consts: ["MyClass", "CODEOBJ: InjectFieldFromInit_MyClass", 1, 14, 20, "None"],
  co_names: ["MyClass", "obj", "a", "b", "c", "d"],
  co_locals: [],
  toString: function() { return "CodeObject:InjectFieldFromInit"}
};

var InjectFieldFromInit_MyClass = {
  co_name: "MyClass",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,90,0,3,100,0,3,132,0,0,90,0,4,82,83],
  co_consts: ["None", 1000, 7, "CODEOBJ: InjectFieldFromInit_MyClass___init__"],
  co_names: ["__name__", "__module__", "c", "d", "__init__"],
  co_locals: [],
  toString: function() { return "CodeObject:InjectFieldFromInit_MyClass"}
};

var InjectFieldFromInit_MyClass___init__ = {
  co_name: "__init__",
  co_argcount: 4,
  co_nlocals: 4,
  co_varnames: ["self", "a", "b", "c"],
  co_code: [124,0,1,124,0,0,95,0,0,124,0,2,124,0,0,95,0,2,124,0,3,124,0,0,95,0,3,100,0,0,83],
  co_consts: ["None"],
  co_names: ["a", "self", "b", "c"],
  co_locals: [],
  toString: function() { return "CodeObject:InjectFieldFromInit_MyClass___init__"}
};

