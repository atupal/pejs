try:
  raise
except:
  print 42
