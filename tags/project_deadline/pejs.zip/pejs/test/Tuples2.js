//This file was automatically created with compiler.py

var Tuples2 = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["a", "b"],
  co_code: [100,0,6,90,0,0,101,0,1,101,0,0,131,0,1,90,0,0,101,0,2,101,0,0,131,0,1,90,0,3,101,0,3,100,0,3,25,101,0,3,100,0,0,25,23,101,0,3,100,0,4,25,23,71,72,100,0,5,83],
  co_consts: [1, 30, 11, 0, 2, "None", [1, 30, 11]],
  co_names: ["a", "list", "tuple", "b"],
  co_locals: [],
  toString: function() { return "CodeObject:Tuples2"}
};

