//This file was automatically created with compiler.py

var ImportExisting = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["Functions"],
  co_code: [100,0,0,107,0,0,90,0,0,101,0,0,105,0,1,131,0,0,100,0,1,106,0,3,111,0,9,1,100,0,2,71,72,110,0,1,1,101,0,0,105,0,2,131,0,0,100,0,3,106,0,3,111,0,9,1,100,0,4,71,72,110,0,1,1,101,0,0,105,0,3,100,0,5,106,0,3,111,0,9,1,100,0,6,71,72,110,0,1,1,101,0,0,105,0,4,131,0,0,100,0,7,106,0,3,111,0,9,1,100,0,8,71,72,110,0,1,1,100,0,0,83],
  co_consts: ["None", 1, 121, 2, 122, 3, 123, 4, 124],
  co_names: ["Functions", "one", "two", "three", "four"],
  co_locals: [],
  toString: function() { return "CodeObject:ImportExisting"}
};

