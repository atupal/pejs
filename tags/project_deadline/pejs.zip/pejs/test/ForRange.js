//This file was automatically created with compiler.py

var ForRange = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["i", "j"],
  co_code: [100,0,0,90,0,0,120,0,33,101,0,1,100,0,1,100,0,2,131,0,2,68,93,0,16,90,0,2,101,0,0,100,0,3,23,90,0,0,113,0,22,87,101,0,0,71,72,100,0,4,83],
  co_consts: [0, 5, 47, 1, "None"],
  co_names: ["j", "range", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:ForRange"}
};

