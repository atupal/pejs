//This file was automatically created with compiler.py

var WhileBreak = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["i"],
  co_code: [100,0,0,90,0,0,120,0,40,101,0,1,111,0,32,1,101,0,0,100,0,1,23,90,0,0,101,0,0,100,0,2,106,0,4,111,0,5,1,80,113,0,9,1,113,0,9,1,87,101,0,0,71,72,100,0,3,83],
  co_consts: [0, 1, 41, "None"],
  co_names: ["i", "True"],
  co_locals: [],
  toString: function() { return "CodeObject:WhileBreak"}
};

