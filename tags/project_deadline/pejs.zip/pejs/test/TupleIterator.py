tuple = (3,4,5,6,-7,8,9,-10,-11,12,13,14,15,-16,17,-18,19,-20,-1)

result = 0
for i in tuple:
  result = result + i

print result
