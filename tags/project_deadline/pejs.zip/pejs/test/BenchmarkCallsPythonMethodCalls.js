//This file was automatically created with compiler.py

var BenchmarkCallsPythonMethodCalls = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["PythonMethodCalls"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,131,0,0,1,100,0,2,71,72,100,0,3,83],
  co_consts: ["PythonMethodCalls", "CODEOBJ: BenchmarkCallsPythonMethodCalls_PythonMethodCalls", 42, "None"],
  co_names: ["PythonMethodCalls", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonMethodCalls"}
};

var BenchmarkCallsPythonMethodCalls_PythonMethodCalls = {
  co_name: "PythonMethodCalls",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,100,0,3,100,0,2,23,100,0,4,23,20,90,0,3,100,0,5,90,0,4,100,0,6,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 5, 6, 4, 60, "CODEOBJ: BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonMethodCalls_PythonMethodCalls"}
};

var BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 4,
  co_varnames: ["self", "i", "c", "o"],
  co_code: [100,0,1,102,0,0,100,0,2,132,0,0,131,0,0,89,125,0,2,124,0,2,131,0,0,125,0,3,120,0,1088,116,0,2,124,0,0,105,0,4,131,0,1,68,93,0,1071,125,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,7,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,7,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,7,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,7,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,7,100,0,3,100,0,3,131,0,2,1,124,0,3,105,0,8,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,8,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,8,124,0,1,100,0,3,100,0,4,131,0,3,1,124,0,3,105,0,8,124,0,1,124,0,1,100,0,1,100,0,5,131,0,258,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,7,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,7,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,7,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,7,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,7,100,0,3,100,0,3,131,0,2,1,124,0,3,105,0,8,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,8,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,8,124,0,1,100,0,3,100,0,4,131,0,3,1,124,0,3,105,0,8,124,0,1,124,0,1,100,0,1,100,0,5,131,0,258,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,7,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,7,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,7,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,7,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,7,100,0,3,100,0,3,131,0,2,1,124,0,3,105,0,8,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,8,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,8,124,0,1,100,0,3,100,0,4,131,0,3,1,124,0,3,105,0,8,124,0,1,124,0,1,100,0,1,100,0,5,131,0,258,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,7,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,7,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,7,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,7,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,7,100,0,3,100,0,3,131,0,2,1,124,0,3,105,0,8,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,8,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,8,124,0,1,100,0,3,100,0,4,131,0,3,1,124,0,3,105,0,8,124,0,1,124,0,1,100,0,1,100,0,5,131,0,258,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,6,131,0,0,1,124,0,3,105,0,7,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,7,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,7,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,7,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,7,100,0,3,100,0,3,131,0,2,1,124,0,3,105,0,8,124,0,1,124,0,1,131,0,2,1,124,0,3,105,0,8,124,0,1,100,0,3,131,0,2,1,124,0,3,105,0,8,124,0,1,100,0,3,100,0,4,131,0,3,1,124,0,3,105,0,8,124,0,1,124,0,1,100,0,1,100,0,5,131,0,258,1,113,0,44,87,100,0,0,83],
  co_consts: ["None", "c", "CODEOBJ: BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c", 2, 3, 4],
  co_names: ["c", "o", "xrange", "self", "rounds", "i", "f", "j", "k"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test"}
};

var BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c = {
  co_name: "c",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,90,0,3,100,0,3,132,0,0,90,0,4,100,0,4,132,0,0,90,0,5,100,0,5,100,0,6,132,0,1,90,0,6,82,83],
  co_consts: ["None", 2, "string", "CODEOBJ: BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c_f", "CODEOBJ: BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c_j", 3, "CODEOBJ: BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c_k"],
  co_names: ["__name__", "__module__", "x", "s", "f", "j", "k"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c"}
};

var BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c_f = {
  co_name: "f",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [124,0,0,105,0,1,83],
  co_consts: ["None"],
  co_names: ["self", "x"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c_f"}
};

var BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c_j = {
  co_name: "j",
  co_argcount: 3,
  co_nlocals: 3,
  co_varnames: ["self", "a", "b"],
  co_code: [124,0,1,124,0,0,95,0,2,124,0,2,124,0,0,95,0,4,124,0,0,105,0,2,83],
  co_consts: ["None"],
  co_names: ["a", "self", "y", "b", "t"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c_j"}
};

var BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c_k = {
  co_name: "k",
  co_argcount: 4,
  co_nlocals: 4,
  co_varnames: ["self", "a", "b", "c"],
  co_code: [124,0,1,124,0,0,95,0,2,124,0,2,124,0,0,95,0,4,124,0,3,124,0,0,95,0,6,100,0,0,83],
  co_consts: ["None"],
  co_names: ["a", "self", "y", "b", "s", "c", "t"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonMethodCalls_PythonMethodCalls_test_c_k"}
};

