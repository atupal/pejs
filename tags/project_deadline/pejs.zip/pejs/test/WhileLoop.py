n = 42
i = 1
while i<n:
    i=i+1
print i