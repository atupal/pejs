a = 0
b = 0
c = 0

while b < 10:
  b = b + 1
  while a < 10:
    a = a + 1
  c = c + a
  a = 0

print c - 58
