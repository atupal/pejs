def fun(arg1=10,arg2=4):
  return arg1 + arg2
  
print fun() + fun(1) + fun(14,9)