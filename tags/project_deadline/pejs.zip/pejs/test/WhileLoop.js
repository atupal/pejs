//This file was automatically created with compiler.py

var WhileLoop = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["i", "n"],
  co_code: [100,0,0,90,0,0,100,0,1,90,0,1,120,0,28,101,0,1,101,0,0,106,0,0,111,0,14,1,101,0,1,100,0,1,23,90,0,1,113,0,15,1,87,101,0,1,71,72,100,0,2,83],
  co_consts: [42, 1, "None"],
  co_names: ["n", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:WhileLoop"}
};

