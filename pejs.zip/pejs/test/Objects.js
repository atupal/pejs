//This file was automatically created with compiler.py

var Objects = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["MyClass", "obj"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,90,0,1,101,0,1,105,0,2,131,0,0,71,72,100,0,2,83],
  co_consts: ["MyClass", "CODEOBJ: Objects_MyClass", "None"],
  co_names: ["MyClass", "obj", "myFunct"],
  co_locals: [],
  toString: function() { return "CodeObject:Objects"}
};

var Objects_MyClass = {
  co_name: "MyClass",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,132,0,0,90,0,3,100,0,3,132,0,0,90,0,4,82,83],
  co_consts: ["None", "4", "CODEOBJ: Objects_MyClass_myFunct2", "CODEOBJ: Objects_MyClass_myFunct"],
  co_names: ["__name__", "__module__", "x", "myFunct2", "myFunct"],
  co_locals: [],
  toString: function() { return "CodeObject:Objects_MyClass"}
};

var Objects_MyClass_myFunct2 = {
  co_name: "myFunct2",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,83],
  co_consts: ["None", "2"],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:Objects_MyClass_myFunct2"}
};

var Objects_MyClass_myFunct = {
  co_name: "myFunct",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [124,0,0,105,0,1,124,0,0,105,0,2,131,0,0,23,83],
  co_consts: ["None"],
  co_names: ["self", "x", "myFunct2"],
  co_locals: [],
  toString: function() { return "CodeObject:Objects_MyClass_myFunct"}
};

