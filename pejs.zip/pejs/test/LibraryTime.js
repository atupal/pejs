//This file was automatically created with compiler.py

var LibraryTime = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["stamp", "time"],
  co_code: [100,0,0,107,0,0,90,0,0,101,0,0,105,0,0,131,0,0,90,0,1,101,0,1,100,0,1,106,0,4,111,0,9,1,100,0,2,71,72,110,0,16,1,100,0,3,101,0,2,101,0,1,131,0,1,23,71,72,100,0,0,83],
  co_consts: ["None", 1227536929, 42, "timestamp was: "],
  co_names: ["time", "stamp", "str"],
  co_locals: [],
  toString: function() { return "CodeObject:LibraryTime"}
};

