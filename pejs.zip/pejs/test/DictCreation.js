//This file was automatically created with compiler.py

var DictCreation = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["dict"],
  co_code: [104,0,0,90,0,0,104,0,0,4,100,0,0,100,0,1,3,60,4,100,0,2,100,0,3,3,60,4,100,0,4,100,0,5,3,60,90,0,0,100,0,6,101,0,0,100,0,7,60,101,0,0,100,0,0,25,101,0,0,100,0,2,25,23,101,0,0,100,0,4,25,23,101,0,0,100,0,7,25,23,71,72,100,0,8,83],
  co_consts: [1, 2, 3, 4, 5, 6, 30, 7, "None"],
  co_names: ["dict"],
  co_locals: [],
  toString: function() { return "CodeObject:DictCreation"}
};

