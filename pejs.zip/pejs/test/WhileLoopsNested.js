//This file was automatically created with compiler.py

var WhileLoopsNested = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["a", "c", "b"],
  co_code: [100,0,0,90,0,0,100,0,0,90,0,1,100,0,0,90,0,2,120,0,75,101,0,1,100,0,1,106,0,0,111,0,61,1,101,0,1,100,0,2,23,90,0,1,120,0,28,101,0,0,100,0,1,106,0,0,111,0,14,1,101,0,0,100,0,2,23,90,0,0,113,0,47,1,87,101,0,2,101,0,0,23,90,0,2,100,0,0,90,0,0,113,0,21,1,87,101,0,2,100,0,3,24,71,72,100,0,4,83],
  co_consts: [0, 10, 1, 58, "None"],
  co_names: ["a", "b", "c"],
  co_locals: [],
  toString: function() { return "CodeObject:WhileLoopsNested"}
};

