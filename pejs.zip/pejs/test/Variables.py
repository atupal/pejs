one = 1
two = one * 2
three = one + two
four = three + two - one
print four + two + 36
