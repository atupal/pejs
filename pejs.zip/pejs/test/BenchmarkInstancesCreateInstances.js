//This file was automatically created with compiler.py

var BenchmarkInstancesCreateInstances = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["CreateInstances"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,131,0,0,1,100,0,2,71,72,100,0,3,83],
  co_consts: ["CreateInstances", "CODEOBJ: BenchmarkInstancesCreateInstances_CreateInstances", 42, "None"],
  co_names: ["CreateInstances", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkInstancesCreateInstances"}
};

var BenchmarkInstancesCreateInstances_CreateInstances = {
  co_name: "CreateInstances",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,100,0,3,23,100,0,4,23,90,0,3,100,0,5,90,0,4,100,0,6,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 3, 7, 4, 800, "CODEOBJ: BenchmarkInstancesCreateInstances_CreateInstances_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkInstancesCreateInstances_CreateInstances"}
};

var BenchmarkInstancesCreateInstances_CreateInstances_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 19,
  co_varnames: ["self", "p2", "p3", "c", "p1", "e", "d", "p4", "p5", "i", "q3", "o", "q", "p", "q2", "p6", "q1", "o2", "o1"],
  co_code: [100,0,1,102,0,0,100,0,2,132,0,0,131,0,0,89,125,0,3,100,0,3,102,0,0,100,0,4,132,0,0,131,0,0,89,125,0,6,100,0,5,102,0,0,100,0,6,132,0,0,131,0,0,89,125,0,5,120,0,245,116,0,3,124,0,0,105,0,5,131,0,1,68,93,0,228,125,0,9,124,0,3,131,0,0,125,0,11,124,0,3,131,0,0,125,0,18,124,0,3,131,0,0,125,0,17,124,0,6,124,0,9,124,0,9,100,0,7,131,0,3,125,0,13,124,0,6,124,0,9,124,0,9,100,0,7,131,0,3,125,0,4,124,0,6,124,0,9,100,0,7,100,0,7,131,0,3,125,0,1,124,0,6,100,0,7,124,0,9,100,0,7,131,0,3,125,0,2,124,0,6,124,0,9,124,0,9,124,0,9,131,0,3,125,0,7,124,0,6,100,0,7,124,0,9,100,0,7,131,0,3,125,0,8,124,0,6,124,0,9,124,0,9,124,0,9,131,0,3,125,0,15,124,0,5,124,0,9,124,0,9,100,0,7,131,0,3,125,0,12,124,0,5,124,0,9,124,0,9,100,0,7,131,0,3,125,0,16,124,0,5,124,0,9,124,0,9,100,0,7,131,0,3,125,0,14,124,0,5,124,0,9,124,0,9,131,0,2,125,0,10,113,0,73,87,100,0,0,83],
  co_consts: ["None", "c", "CODEOBJ: BenchmarkInstancesCreateInstances_CreateInstances_test_c", "d", "CODEOBJ: BenchmarkInstancesCreateInstances_CreateInstances_test_d", "e", "CODEOBJ: BenchmarkInstancesCreateInstances_CreateInstances_test_e", 3],
  co_names: ["c", "d", "e", "xrange", "self", "rounds", "i", "o", "o1", "o2", "p", "p1", "p2", "p3", "p4", "p5", "p6", "q", "q1", "q2", "q3"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkInstancesCreateInstances_CreateInstances_test"}
};

var BenchmarkInstancesCreateInstances_CreateInstances_test_c = {
  co_name: "c",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,82,83],
  co_consts: ["None"],
  co_names: ["__name__", "__module__"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkInstancesCreateInstances_CreateInstances_test_c"}
};

var BenchmarkInstancesCreateInstances_CreateInstances_test_d = {
  co_name: "d",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,132,0,0,90,0,2,82,83],
  co_consts: ["None", "CODEOBJ: BenchmarkInstancesCreateInstances_CreateInstances_test_d___init__"],
  co_names: ["__name__", "__module__", "__init__"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkInstancesCreateInstances_CreateInstances_test_d"}
};

var BenchmarkInstancesCreateInstances_CreateInstances_test_e = {
  co_name: "e",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,100,0,2,132,0,1,90,0,2,82,83],
  co_consts: ["None", 4, "CODEOBJ: BenchmarkInstancesCreateInstances_CreateInstances_test_e___init__"],
  co_names: ["__name__", "__module__", "__init__"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkInstancesCreateInstances_CreateInstances_test_e"}
};

var BenchmarkInstancesCreateInstances_CreateInstances_test_d___init__ = {
  co_name: "__init__",
  co_argcount: 4,
  co_nlocals: 4,
  co_varnames: ["self", "a", "b", "c"],
  co_code: [124,0,1,124,0,0,95,0,0,124,0,2,124,0,0,95,0,2,124,0,3,124,0,0,95,0,3,100,0,0,83],
  co_consts: ["None"],
  co_names: ["a", "self", "b", "c"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkInstancesCreateInstances_CreateInstances_test_d___init__"}
};

var BenchmarkInstancesCreateInstances_CreateInstances_test_e___init__ = {
  co_name: "__init__",
  co_argcount: 4,
  co_nlocals: 4,
  co_varnames: ["self", "a", "b", "c"],
  co_code: [124,0,1,124,0,0,95,0,0,124,0,2,124,0,0,95,0,2,124,0,3,124,0,0,95,0,3,124,0,1,124,0,0,95,0,4,124,0,2,124,0,0,95,0,5,124,0,3,124,0,0,95,0,6,100,0,0,83],
  co_consts: ["None"],
  co_names: ["a", "self", "b", "c", "d", "e", "f"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkInstancesCreateInstances_CreateInstances_test_e___init__"}
};

