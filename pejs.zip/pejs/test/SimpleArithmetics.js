//This file was automatically created with compiler.py

var SimpleArithmetics = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,0,100,0,1,23,100,0,2,23,100,0,0,100,0,1,23,23,100,0,3,100,0,4,20,24,100,0,5,23,71,72,100,0,6,83],
  co_consts: [2, 5, 4, 10, 3, 54, "None"],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:SimpleArithmetics"}
};

