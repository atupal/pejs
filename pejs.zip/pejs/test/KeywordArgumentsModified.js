//This file was automatically created with compiler.py

var KeywordArgumentsModified = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["incDict", "dict"],
  co_code: [104,0,0,4,100,0,0,100,0,1,3,60,4,100,0,2,100,0,3,3,60,4,100,0,4,100,0,5,3,60,4,100,0,6,100,0,7,3,60,4,100,0,8,100,0,9,3,60,90,0,0,100,0,10,132,0,0,90,0,1,101,0,1,101,0,0,141,0,0,1,101,0,0,100,0,0,25,101,0,0,100,0,2,25,23,101,0,0,100,0,4,25,23,101,0,0,100,0,6,25,23,101,0,0,100,0,8,25,23,100,0,11,23,71,72,100,0,12,83],
  co_consts: ["a", 1, "b", 2, "c", 3, "d", 4, "e", 5, "CODEOBJ: KeywordArgumentsModified_incDict", 27, "None"],
  co_names: ["dict", "incDict"],
  co_locals: [],
  toString: function() { return "CodeObject:KeywordArgumentsModified"}
};

var KeywordArgumentsModified_incDict = {
  co_name: "incDict",
  co_argcount: 0,
  co_nlocals: 1,
  co_varnames: ["args"],
  co_code: [124,0,0,100,0,1,25,124,0,0,100,0,2,60,124,0,0,100,0,3,25,124,0,0,100,0,1,60,124,0,0,100,0,4,25,124,0,0,100,0,3,60,124,0,0,100,0,5,25,124,0,0,100,0,4,60,124,0,0,100,0,5,25,100,0,6,24,124,0,0,100,0,5,60,100,0,0,83],
  co_consts: ["None", "d", "e", "c", "b", "a", 1],
  co_names: ["args"],
  co_locals: [],
  toString: function() { return "CodeObject:KeywordArgumentsModified_incDict"}
};

