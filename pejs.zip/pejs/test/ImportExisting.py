import Functions #This will print 42 if executed properly

if Functions.one() != 1:
  print 121

if Functions.two() != 2:
  print 122

if Functions.three != 3:
  print 123

if Functions.four() != 4:
  print 124