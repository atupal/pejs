//This file was automatically created with compiler.py

var VariablesInFunctionCall = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["fun", "i"],
  co_code: [100,0,0,132,0,0,90,0,0,100,0,1,90,0,1,101,0,0,101,0,1,131,0,1,1,101,0,1,71,72,100,0,2,83],
  co_consts: ["CODEOBJ: VariablesInFunctionCall_fun", 42, "None"],
  co_names: ["fun", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:VariablesInFunctionCall"}
};

var VariablesInFunctionCall_fun = {
  co_name: "fun",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["n"],
  co_code: [100,0,1,125,0,0,100,0,0,83],
  co_consts: ["None", 100],
  co_names: ["n"],
  co_locals: [],
  toString: function() { return "CodeObject:VariablesInFunctionCall_fun"}
};

