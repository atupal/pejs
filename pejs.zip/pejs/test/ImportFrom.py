from Objects import MyClass

obj = MyClass()
if obj.x != "4":
  print 123
  
if obj.myFunct2() != "2":
  print 1234
  
if obj.myFunct() != "42":
  print 12345