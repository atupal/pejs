//This file was automatically created with compiler.py

var TryExceptFinally = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["i"],
  co_code: [100,0,0,90,0,0,122,0,51,121,0,27,101,0,0,100,0,1,23,90,0,0,130,0,0,101,0,0,100,0,2,23,90,0,0,87,110,0,17,1,1,1,101,0,0,100,0,1,23,90,0,0,110,0,1,88,87,100,0,3,101,0,0,100,0,1,23,90,0,0,88,122,0,38,121,0,14,101,0,0,100,0,1,23,90,0,0,87,110,0,17,1,1,1,101,0,0,100,0,2,23,90,0,0,110,0,1,88,87,100,0,3,101,0,0,100,0,4,23,90,0,0,88,101,0,0,71,72,100,0,3,83],
  co_consts: [0, 10, 100, "None", 2],
  co_names: ["i"],
  co_locals: [],
  toString: function() { return "CodeObject:TryExceptFinally"}
};

