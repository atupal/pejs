//This file was automatically created with compiler.py

var ImportFrom = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["MyClass", "obj"],
  co_code: [100,0,0,107,0,0,108,0,1,90,0,1,1,101,0,1,131,0,0,90,0,2,101,0,2,105,0,3,100,0,1,106,0,3,111,0,9,1,100,0,2,71,72,110,0,1,1,101,0,2,105,0,4,131,0,0,100,0,3,106,0,3,111,0,9,1,100,0,4,71,72,110,0,1,1,101,0,2,105,0,5,131,0,0,100,0,5,106,0,3,111,0,9,1,100,0,6,71,72,110,0,1,1,100,0,7,83],
  co_consts: [["MyClass"], "4", 123, "2", 1234, "42", 12345, "None"],
  co_names: ["Objects", "MyClass", "obj", "x", "myFunct2", "myFunct"],
  co_locals: [],
  toString: function() { return "CodeObject:ImportFrom"}
};

