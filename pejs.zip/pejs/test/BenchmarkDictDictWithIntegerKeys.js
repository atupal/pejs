//This file was automatically created with compiler.py

var BenchmarkDictDictWithIntegerKeys = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["DictWithIntegerKeys"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,131,0,0,1,100,0,2,71,72,100,0,3,83],
  co_consts: ["DictWithIntegerKeys", "CODEOBJ: BenchmarkDictDictWithIntegerKeys_DictWithIntegerKeys", 42, "None"],
  co_names: ["DictWithIntegerKeys", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkDictDictWithIntegerKeys"}
};

var BenchmarkDictDictWithIntegerKeys_DictWithIntegerKeys = {
  co_name: "DictWithIntegerKeys",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,100,0,3,100,0,3,23,20,90,0,3,100,0,4,90,0,4,100,0,5,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 5, 6, 2000, "CODEOBJ: BenchmarkDictDictWithIntegerKeys_DictWithIntegerKeys_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkDictDictWithIntegerKeys_DictWithIntegerKeys"}
};

var BenchmarkDictDictWithIntegerKeys_DictWithIntegerKeys_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 3,
  co_varnames: ["self", "i", "d"],
  co_code: [104,0,0,125,0,2,120,0,563,116,0,1,124,0,0,105,0,3,131,0,1,68,93,0,546,125,0,1,100,0,1,124,0,2,100,0,1,60,100,0,2,124,0,2,100,0,2,60,100,0,3,124,0,2,100,0,3,60,100,0,4,124,0,2,100,0,4,60,100,0,5,124,0,2,100,0,5,60,100,0,6,124,0,2,100,0,6,60,124,0,2,100,0,1,25,1,124,0,2,100,0,2,25,1,124,0,2,100,0,3,25,1,124,0,2,100,0,4,25,1,124,0,2,100,0,5,25,1,124,0,2,100,0,6,25,1,100,0,1,124,0,2,100,0,1,60,100,0,2,124,0,2,100,0,2,60,100,0,3,124,0,2,100,0,3,60,100,0,4,124,0,2,100,0,4,60,100,0,5,124,0,2,100,0,5,60,100,0,6,124,0,2,100,0,6,60,124,0,2,100,0,1,25,1,124,0,2,100,0,2,25,1,124,0,2,100,0,3,25,1,124,0,2,100,0,4,25,1,124,0,2,100,0,5,25,1,124,0,2,100,0,6,25,1,100,0,1,124,0,2,100,0,1,60,100,0,2,124,0,2,100,0,2,60,100,0,3,124,0,2,100,0,3,60,100,0,4,124,0,2,100,0,4,60,100,0,5,124,0,2,100,0,5,60,100,0,6,124,0,2,100,0,6,60,124,0,2,100,0,1,25,1,124,0,2,100,0,2,25,1,124,0,2,100,0,3,25,1,124,0,2,100,0,4,25,1,124,0,2,100,0,5,25,1,124,0,2,100,0,6,25,1,100,0,1,124,0,2,100,0,1,60,100,0,2,124,0,2,100,0,2,60,100,0,3,124,0,2,100,0,3,60,100,0,4,124,0,2,100,0,4,60,100,0,5,124,0,2,100,0,5,60,100,0,6,124,0,2,100,0,6,60,124,0,2,100,0,1,25,1,124,0,2,100,0,2,25,1,124,0,2,100,0,3,25,1,124,0,2,100,0,4,25,1,124,0,2,100,0,5,25,1,124,0,2,100,0,6,25,1,100,0,1,124,0,2,100,0,1,60,100,0,2,124,0,2,100,0,2,60,100,0,3,124,0,2,100,0,3,60,100,0,4,124,0,2,100,0,4,60,100,0,5,124,0,2,100,0,5,60,100,0,6,124,0,2,100,0,6,60,124,0,2,100,0,1,25,1,124,0,2,100,0,2,25,1,124,0,2,100,0,3,25,1,124,0,2,100,0,4,25,1,124,0,2,100,0,5,25,1,124,0,2,100,0,6,25,1,113,0,22,87,100,0,0,83],
  co_consts: ["None", 1, 2, 3, 4, 5, 6],
  co_names: ["d", "xrange", "self", "rounds", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkDictDictWithIntegerKeys_DictWithIntegerKeys_test"}
};

