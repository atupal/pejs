j = 0
for i in xrange(42):
  j = j + 1
print j
