//This file was automatically created with compiler.py

var BenchmarkStringsCreateStringsWithConcat = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["CreateStringsWithConcat"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,131,0,0,1,100,0,2,71,72,100,0,3,83],
  co_consts: ["CreateStringsWithConcat", "CODEOBJ: BenchmarkStringsCreateStringsWithConcat_CreateStringsWithConcat", 42, "None"],
  co_names: ["CreateStringsWithConcat", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkStringsCreateStringsWithConcat"}
};

var BenchmarkStringsCreateStringsWithConcat_CreateStringsWithConcat = {
  co_name: "CreateStringsWithConcat",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,100,0,3,20,90,0,3,100,0,4,90,0,4,100,0,5,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 10, 5, 2000, "CODEOBJ: BenchmarkStringsCreateStringsWithConcat_CreateStringsWithConcat_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkStringsCreateStringsWithConcat_CreateStringsWithConcat"}
};

var BenchmarkStringsCreateStringsWithConcat_CreateStringsWithConcat_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 3,
  co_varnames: ["self", "i", "s"],
  co_code: [120,0,519,116,0,0,124,0,0,105,0,2,131,0,1,68,93,0,502,125,0,1,100,0,1,125,0,2,124,0,2,100,0,2,23,125,0,2,124,0,2,100,0,3,23,125,0,2,124,0,2,100,0,4,23,125,0,2,124,0,2,100,0,5,23,125,0,2,124,0,2,100,0,6,23,125,0,2,124,0,2,100,0,2,23,125,0,2,124,0,2,100,0,3,23,125,0,2,124,0,2,100,0,4,23,125,0,2,124,0,2,100,0,5,23,125,0,2,124,0,2,100,0,6,23,125,0,2,124,0,2,100,0,2,23,125,0,2,124,0,2,100,0,3,23,125,0,2,124,0,2,100,0,4,23,125,0,2,124,0,2,100,0,5,23,125,0,2,124,0,2,100,0,6,23,125,0,2,124,0,2,100,0,2,23,125,0,2,124,0,2,100,0,3,23,125,0,2,124,0,2,100,0,4,23,125,0,2,124,0,2,100,0,5,23,125,0,2,124,0,2,100,0,6,23,125,0,2,124,0,2,100,0,2,23,125,0,2,124,0,2,100,0,3,23,125,0,2,124,0,2,100,0,4,23,125,0,2,124,0,2,100,0,5,23,125,0,2,124,0,2,100,0,6,23,125,0,2,124,0,2,100,0,2,23,125,0,2,124,0,2,100,0,3,23,125,0,2,124,0,2,100,0,4,23,125,0,2,124,0,2,100,0,5,23,125,0,2,124,0,2,100,0,6,23,125,0,2,124,0,2,100,0,2,23,125,0,2,124,0,2,100,0,3,23,125,0,2,124,0,2,100,0,4,23,125,0,2,124,0,2,100,0,5,23,125,0,2,124,0,2,100,0,6,23,125,0,2,124,0,2,100,0,2,23,125,0,2,124,0,2,100,0,3,23,125,0,2,124,0,2,100,0,4,23,125,0,2,124,0,2,100,0,5,23,125,0,2,124,0,2,100,0,6,23,125,0,2,124,0,2,100,0,2,23,125,0,2,124,0,2,100,0,3,23,125,0,2,124,0,2,100,0,4,23,125,0,2,124,0,2,100,0,5,23,125,0,2,124,0,2,100,0,6,23,125,0,2,124,0,2,100,0,2,23,125,0,2,124,0,2,100,0,3,23,125,0,2,124,0,2,100,0,4,23,125,0,2,124,0,2,100,0,5,23,125,0,2,113,0,16,87,100,0,0,83],
  co_consts: ["None", "om", "xbx", "xcx", "xdx", "xex", "xax"],
  co_names: ["xrange", "self", "rounds", "i", "s"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkStringsCreateStringsWithConcat_CreateStringsWithConcat_test"}
};

