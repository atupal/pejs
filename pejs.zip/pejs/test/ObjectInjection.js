//This file was automatically created with compiler.py

var ObjectInjection = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["MyObject", "obj"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,100,0,2,100,0,3,131,0,2,90,0,1,100,0,3,101,0,1,95,0,2,101,0,1,105,0,3,101,0,1,105,0,2,23,71,72,100,0,4,83],
  co_consts: ["MyObject", "CODEOBJ: ObjectInjection_MyObject", 40, 1, "None"],
  co_names: ["MyObject", "obj", "newField", "myField"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectInjection"}
};

var ObjectInjection_MyObject = {
  co_name: "MyObject",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,132,0,0,90,0,3,82,83],
  co_consts: ["None", 0, "CODEOBJ: ObjectInjection_MyObject___init__"],
  co_names: ["__name__", "__module__", "myField", "__init__"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectInjection_MyObject"}
};

var ObjectInjection_MyObject___init__ = {
  co_name: "__init__",
  co_argcount: 3,
  co_nlocals: 3,
  co_varnames: ["self", "arg1", "arg2"],
  co_code: [124,0,1,124,0,2,23,124,0,0,95,0,3,100,0,0,83],
  co_consts: ["None"],
  co_names: ["arg1", "arg2", "self", "myField"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectInjection_MyObject___init__"}
};

