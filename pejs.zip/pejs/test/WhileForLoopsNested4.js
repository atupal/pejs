//This file was automatically created with compiler.py

var WhileForLoopsNested4 = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["a", "b", "l"],
  co_code: [100,0,0,90,0,0,100,0,0,90,0,1,120,0,64,101,0,0,100,0,1,106,0,0,111,0,50,1,101,0,0,100,0,2,23,90,0,0,120,0,33,101,0,2,100,0,0,100,0,1,131,0,2,68,93,0,16,90,0,3,101,0,1,100,0,2,23,90,0,1,113,0,54,87,113,0,15,1,87,101,0,1,100,0,3,20,101,0,0,23,71,72,100,0,4,83],
  co_consts: [0, 2, 1, 10, "None"],
  co_names: ["a", "b", "range", "l"],
  co_locals: [],
  toString: function() { return "CodeObject:WhileForLoopsNested4"}
};

