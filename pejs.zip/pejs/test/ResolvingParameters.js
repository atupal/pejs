//This file was automatically created with compiler.py

var ResolvingParameters = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["c"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,100,0,2,100,0,3,100,0,4,103,0,2,104,0,0,4,100,0,5,100,0,6,3,60,142,0,1,100,0,7,23,71,72,100,0,8,83],
  co_consts: ["c", "CODEOBJ: ResolvingParameters_c", 1, 2, 9, "d", 6, 24, "None"],
  co_names: ["c", "f"],
  co_locals: [],
  toString: function() { return "CodeObject:ResolvingParameters"}
};

var ResolvingParameters_c = {
  co_name: "c",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,100,0,2,100,0,3,132,0,2,90,0,2,82,83],
  co_consts: ["None", 3, 4, "CODEOBJ: ResolvingParameters_c_f"],
  co_names: ["__name__", "__module__", "f"],
  co_locals: [],
  toString: function() { return "CodeObject:ResolvingParameters_c"}
};

var ResolvingParameters_c_f = {
  co_name: "f",
  co_argcount: 5,
  co_nlocals: 8,
  co_varnames: ["self", "a", "b", "c", "d", "tuple", "dict", "l"],
  co_code: [124,0,1,124,0,2,23,124,0,3,23,124,0,4,23,125,0,7,124,0,7,83],
  co_consts: ["None"],
  co_names: ["a", "b", "c", "d", "l"],
  co_locals: [],
  toString: function() { return "CodeObject:ResolvingParameters_c_f"}
};

