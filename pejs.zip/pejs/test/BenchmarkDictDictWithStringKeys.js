//This file was automatically created with compiler.py

var BenchmarkDictDictWithStringKeys = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["DictWithStringKeys"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,131,0,0,1,100,0,2,71,72,100,0,3,83],
  co_consts: ["DictWithStringKeys", "CODEOBJ: BenchmarkDictDictWithStringKeys_DictWithStringKeys", 42, "None"],
  co_names: ["DictWithStringKeys", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkDictDictWithStringKeys"}
};

var BenchmarkDictDictWithStringKeys_DictWithStringKeys = {
  co_name: "DictWithStringKeys",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,100,0,3,100,0,3,23,20,90,0,3,100,0,4,90,0,4,100,0,5,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 5, 6, 2000, "CODEOBJ: BenchmarkDictDictWithStringKeys_DictWithStringKeys_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkDictDictWithStringKeys_DictWithStringKeys"}
};

var BenchmarkDictDictWithStringKeys_DictWithStringKeys_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 3,
  co_varnames: ["self", "i", "d"],
  co_code: [104,0,0,125,0,2,120,0,563,116,0,1,124,0,0,105,0,3,131,0,1,68,93,0,546,125,0,1,100,0,1,124,0,2,100,0,2,60,100,0,3,124,0,2,100,0,4,60,100,0,5,124,0,2,100,0,6,60,100,0,7,124,0,2,100,0,8,60,100,0,9,124,0,2,100,0,10,60,100,0,11,124,0,2,100,0,12,60,124,0,2,100,0,2,25,1,124,0,2,100,0,4,25,1,124,0,2,100,0,6,25,1,124,0,2,100,0,8,25,1,124,0,2,100,0,10,25,1,124,0,2,100,0,12,25,1,100,0,1,124,0,2,100,0,2,60,100,0,3,124,0,2,100,0,4,60,100,0,5,124,0,2,100,0,6,60,100,0,7,124,0,2,100,0,8,60,100,0,9,124,0,2,100,0,10,60,100,0,11,124,0,2,100,0,12,60,124,0,2,100,0,2,25,1,124,0,2,100,0,4,25,1,124,0,2,100,0,6,25,1,124,0,2,100,0,8,25,1,124,0,2,100,0,10,25,1,124,0,2,100,0,12,25,1,100,0,1,124,0,2,100,0,2,60,100,0,3,124,0,2,100,0,4,60,100,0,5,124,0,2,100,0,6,60,100,0,7,124,0,2,100,0,8,60,100,0,9,124,0,2,100,0,10,60,100,0,11,124,0,2,100,0,12,60,124,0,2,100,0,2,25,1,124,0,2,100,0,4,25,1,124,0,2,100,0,6,25,1,124,0,2,100,0,8,25,1,124,0,2,100,0,10,25,1,124,0,2,100,0,12,25,1,100,0,1,124,0,2,100,0,2,60,100,0,3,124,0,2,100,0,4,60,100,0,5,124,0,2,100,0,6,60,100,0,7,124,0,2,100,0,8,60,100,0,9,124,0,2,100,0,10,60,100,0,11,124,0,2,100,0,12,60,124,0,2,100,0,2,25,1,124,0,2,100,0,4,25,1,124,0,2,100,0,6,25,1,124,0,2,100,0,8,25,1,124,0,2,100,0,10,25,1,124,0,2,100,0,12,25,1,100,0,1,124,0,2,100,0,2,60,100,0,3,124,0,2,100,0,4,60,100,0,5,124,0,2,100,0,6,60,100,0,7,124,0,2,100,0,8,60,100,0,9,124,0,2,100,0,10,60,100,0,11,124,0,2,100,0,12,60,124,0,2,100,0,2,25,1,124,0,2,100,0,4,25,1,124,0,2,100,0,6,25,1,124,0,2,100,0,8,25,1,124,0,2,100,0,10,25,1,124,0,2,100,0,12,25,1,113,0,22,87,100,0,0,83],
  co_consts: ["None", 1, "abc", 2, "def", 3, "ghi", 4, "jkl", 5, "mno", 6, "pqr"],
  co_names: ["d", "xrange", "self", "rounds", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkDictDictWithStringKeys_DictWithStringKeys_test"}
};

