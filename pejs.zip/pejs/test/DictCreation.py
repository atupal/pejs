dict = {}
dict = {1:2,3:4,5:6}
dict[7] = 30

print dict[1] + dict[3] + dict[5] + dict[7]