//This file was automatically created with compiler.py

var InitMethod = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["i", "MyClass", "result"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,100,0,2,90,0,1,120,0,36,101,0,2,100,0,3,131,0,1,68,93,0,22,90,0,3,101,0,1,101,0,0,131,0,0,105,0,4,23,90,0,1,113,0,38,87,101,0,1,71,72,100,0,4,83],
  co_consts: ["MyClass", "CODEOBJ: InitMethod_MyClass", 0, 21, "None"],
  co_names: ["MyClass", "result", "xrange", "i", "a"],
  co_locals: [],
  toString: function() { return "CodeObject:InitMethod"}
};

var InitMethod_MyClass = {
  co_name: "MyClass",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,132,0,0,90,0,2,82,83],
  co_consts: ["None", "CODEOBJ: InitMethod_MyClass___init__"],
  co_names: ["__name__", "__module__", "__init__"],
  co_locals: [],
  toString: function() { return "CodeObject:InitMethod_MyClass"}
};

var InitMethod_MyClass___init__ = {
  co_name: "__init__",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["self"],
  co_code: [100,0,1,124,0,0,95,0,1,100,0,0,83],
  co_consts: ["None", 2],
  co_names: ["self", "a"],
  co_locals: [],
  toString: function() { return "CodeObject:InitMethod_MyClass___init__"}
};

