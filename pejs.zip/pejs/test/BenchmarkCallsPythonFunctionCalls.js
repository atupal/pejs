//This file was automatically created with compiler.py

var BenchmarkCallsPythonFunctionCalls = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["PythonFunctionCalls"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,131,0,0,1,100,0,2,71,72,100,0,3,83],
  co_consts: ["PythonFunctionCalls", "CODEOBJ: BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls", 42, "None"],
  co_names: ["PythonFunctionCalls", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonFunctionCalls"}
};

var BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls = {
  co_name: "PythonFunctionCalls",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,100,0,3,100,0,4,23,100,0,4,23,100,0,5,23,20,90,0,3,100,0,6,90,0,4,100,0,7,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 5, 1, 4, 2, 120, "CODEOBJ: BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls"}
};

var BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 2,
  co_varnames: ["self", "i"],
  co_code: [100,0,1,132,0,0,97,0,0,100,0,2,132,0,0,97,0,1,100,0,3,132,0,0,97,0,2,100,0,4,100,0,5,100,0,6,100,0,7,132,0,3,97,0,3,120,0,813,116,0,4,124,0,0,105,0,6,131,0,1,68,93,0,796,125,0,1,116,0,0,131,0,0,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,3,124,0,1,124,0,1,100,0,6,124,0,1,124,0,1,131,0,5,1,116,0,3,124,0,1,124,0,1,124,0,1,100,0,5,124,0,1,100,0,6,131,0,6,1,116,0,0,131,0,0,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,3,124,0,1,124,0,1,100,0,6,124,0,1,124,0,1,131,0,5,1,116,0,3,124,0,1,124,0,1,124,0,1,100,0,5,124,0,1,100,0,6,131,0,6,1,116,0,0,131,0,0,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,3,124,0,1,124,0,1,100,0,6,124,0,1,124,0,1,131,0,5,1,116,0,3,124,0,1,124,0,1,124,0,1,100,0,5,124,0,1,100,0,6,131,0,6,1,116,0,0,131,0,0,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,3,124,0,1,124,0,1,100,0,6,124,0,1,124,0,1,131,0,5,1,116,0,3,124,0,1,124,0,1,124,0,1,100,0,5,124,0,1,100,0,6,131,0,6,1,116,0,0,131,0,0,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,1,124,0,1,131,0,1,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,2,124,0,1,124,0,1,124,0,1,131,0,3,1,116,0,3,124,0,1,124,0,1,100,0,6,124,0,1,124,0,1,131,0,5,1,116,0,3,124,0,1,124,0,1,124,0,1,100,0,5,124,0,1,100,0,6,131,0,6,1,113,0,61,87,100,0,0,83],
  co_consts: ["None", "CODEOBJ: BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_f", "CODEOBJ: BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_f1", "CODEOBJ: BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_g", 1, 2, 3, "CODEOBJ: BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_h"],
  co_names: ["f", "f1", "g", "h", "xrange", "self", "rounds", "i"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test"}
};

var BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_f = {
  co_name: "f",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,0,83],
  co_consts: ["None"],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_f"}
};

var BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_f1 = {
  co_name: "f1",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["x"],
  co_code: [100,0,0,83],
  co_consts: ["None"],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_f1"}
};

var BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_g = {
  co_name: "g",
  co_argcount: 3,
  co_nlocals: 3,
  co_varnames: ["a", "b", "c"],
  co_code: [124,0,0,124,0,1,124,0,2,102,0,3,83],
  co_consts: ["None"],
  co_names: ["a", "b", "c"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_g"}
};

var BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_h = {
  co_name: "h",
  co_argcount: 6,
  co_nlocals: 6,
  co_varnames: ["a", "b", "c", "d", "e", "f"],
  co_code: [124,0,3,124,0,4,124,0,5,102,0,3,83],
  co_consts: ["None"],
  co_names: ["d", "e", "f"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkCallsPythonFunctionCalls_PythonFunctionCalls_test_h"}
};

