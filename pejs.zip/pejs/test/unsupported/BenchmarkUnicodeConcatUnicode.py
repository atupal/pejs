from string import join

class ConcatUnicode:

    version = 2.0
    operations = 10 * 5
    rounds = 6#0000

    def test(self):

        # Make sure the strings are *not* interned
        s = unicode(join(map(str,range(100))))
        t = unicode(join(map(str,range(1,101))))

        for i in xrange(self.rounds):
            t + s
            t + s
            t + s
            t + s
            t + s

            t + s
            t + s
            t + s
            t + s
            t + s

            t + s
            t + s
            t + s
            t + s
            t + s

            t + s
            t + s
            t + s
            t + s
            t + s

            t + s
            t + s
            t + s
            t + s
            t + s

            t + s
            t + s
            t + s
            t + s
            t + s

            t + s
            t + s
            t + s
            t + s
            t + s

            t + s
            t + s
            t + s
            t + s
            t + s

            t + s
            t + s
            t + s
            t + s
            t + s

            t + s
            t + s
            t + s
            t + s
            t + s

ConcatUnicode().test()

print 42