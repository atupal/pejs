# First import:
import os

class SecondImport:

    version = 2.0
    operations = 5 * 5
    rounds = 4#0000

    def test(self):

        for i in xrange(self.rounds):
            import os
            import os
            import os
            import os
            import os

            import os
            import os
            import os
            import os
            import os

            import os
            import os
            import os
            import os
            import os

            import os
            import os
            import os
            import os
            import os

            import os
            import os
            import os
            import os
            import os

SecondImport().test()

print 42