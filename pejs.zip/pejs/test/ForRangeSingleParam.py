j = 0
for i in range(42):
  j = j + 1
print j
