//This file was automatically created with compiler.py

var ObjectInitialization2 = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["obj1", "obj2", "MyObject"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,100,0,2,131,0,1,90,0,1,101,0,0,100,0,3,131,0,1,90,0,2,101,0,1,105,0,3,101,0,2,105,0,3,23,71,72,100,0,4,83],
  co_consts: ["MyObject", "CODEOBJ: ObjectInitialization2_MyObject", "4", "2", "None"],
  co_names: ["MyObject", "obj1", "obj2", "myField"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectInitialization2"}
};

var ObjectInitialization2_MyObject = {
  co_name: "MyObject",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,132,0,0,90,0,3,82,83],
  co_consts: ["None", "", "CODEOBJ: ObjectInitialization2_MyObject___init__"],
  co_names: ["__name__", "__module__", "myField", "__init__"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectInitialization2_MyObject"}
};

var ObjectInitialization2_MyObject___init__ = {
  co_name: "__init__",
  co_argcount: 2,
  co_nlocals: 2,
  co_varnames: ["self", "arg"],
  co_code: [124,0,1,124,0,0,95,0,2,100,0,0,83],
  co_consts: ["None"],
  co_names: ["arg", "self", "myField"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectInitialization2_MyObject___init__"}
};

