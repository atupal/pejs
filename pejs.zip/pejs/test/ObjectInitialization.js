//This file was automatically created with compiler.py

var ObjectInitialization = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["MyObject"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,100,0,2,100,0,3,131,0,2,105,0,1,71,72,100,0,4,83],
  co_consts: ["MyObject", "CODEOBJ: ObjectInitialization_MyObject", "4", "2", "None"],
  co_names: ["MyObject", "myField"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectInitialization"}
};

var ObjectInitialization_MyObject = {
  co_name: "MyObject",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,132,0,0,90,0,3,82,83],
  co_consts: ["None", "", "CODEOBJ: ObjectInitialization_MyObject___init__"],
  co_names: ["__name__", "__module__", "myField", "__init__"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectInitialization_MyObject"}
};

var ObjectInitialization_MyObject___init__ = {
  co_name: "__init__",
  co_argcount: 3,
  co_nlocals: 3,
  co_varnames: ["self", "arg1", "arg2"],
  co_code: [124,0,1,124,0,2,23,124,0,0,95,0,3,100,0,0,83],
  co_consts: ["None"],
  co_names: ["arg1", "arg2", "self", "myField"],
  co_locals: [],
  toString: function() { return "CodeObject:ObjectInitialization_MyObject___init__"}
};

