//This file was automatically created with compiler.py

var KeywordArguments = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["f", "args", "result", "kwargs", "fun"],
  co_code: [100,0,0,100,0,1,100,0,2,100,0,3,132,0,3,90,0,0,100,0,20,90,0,1,100,0,4,132,0,0,90,0,2,101,0,3,100,0,5,100,0,2,100,0,6,100,0,7,100,0,8,100,0,9,131,0,768,90,0,4,101,0,0,100,0,10,100,0,2,100,0,11,100,0,0,100,0,5,100,0,12,131,0,768,90,0,5,101,0,5,101,0,0,100,0,13,100,0,2,100,0,8,100,0,12,100,0,6,100,0,1,100,0,5,100,0,14,100,0,11,100,0,15,100,0,10,100,0,16,131,0,1536,23,90,0,5,101,0,5,101,0,0,100,0,16,100,0,11,100,0,2,101,0,4,141,0,257,23,90,0,5,101,0,5,101,0,0,101,0,1,101,0,4,142,0,0,23,90,0,5,101,0,5,101,0,0,100,0,1,100,0,21,140,0,1,23,90,0,5,101,0,5,101,0,2,100,0,0,100,0,1,100,0,7,100,0,16,100,0,17,100,0,2,100,0,13,100,0,1,100,0,18,100,0,9,131,0,772,23,71,72,100,0,19,83],
  co_consts: [1, 2, 3, "CODEOBJ: KeywordArguments_f", "CODEOBJ: KeywordArguments_fun", "c", "d", 4, "e", 5, "a", "b", 9, "f", 8, 0, 6, "m", "g", "None", [1, 2], [3, 4]],
  co_names: ["f", "args", "fun", "dict", "kwargs", "result"],
  co_locals: [],
  toString: function() { return "CodeObject:KeywordArguments"}
};

var KeywordArguments_f = {
  co_name: "f",
  co_argcount: 6,
  co_nlocals: 6,
  co_varnames: ["a", "b", "c", "d", "e", "f"],
  co_code: [124,0,0,124,0,1,24,124,0,2,23,124,0,3,24,124,0,4,23,124,0,5,24,83],
  co_consts: ["None"],
  co_names: ["a", "b", "c", "d", "e", "f"],
  co_locals: [],
  toString: function() { return "CodeObject:KeywordArguments_f"}
};

var KeywordArguments_fun = {
  co_name: "fun",
  co_argcount: 2,
  co_nlocals: 4,
  co_varnames: ["a", "b", "tuple", "dict"],
  co_code: [124,0,0,124,0,1,23,124,0,2,100,0,1,25,23,124,0,3,100,0,2,25,23,83],
  co_consts: ["None", 0, "m"],
  co_names: ["a", "b", "tuple", "dict"],
  co_locals: [],
  toString: function() { return "CodeObject:KeywordArguments_fun"}
};

