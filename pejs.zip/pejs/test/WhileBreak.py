i = 0
while True:
  i = i + 1
  if i > 41:
    break
print i
