//This file was automatically created with compiler.py

var Functions = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["three", "two", "four", "add", "one", "inc"],
  co_code: [100,0,0,132,0,0,90,0,0,100,0,1,132,0,0,90,0,1,100,0,2,132,0,0,90,0,2,101,0,2,101,0,0,131,0,0,101,0,1,131,0,0,131,0,2,90,0,3,100,0,3,132,0,0,90,0,4,100,0,4,132,0,0,90,0,5,101,0,6,101,0,5,131,0,0,131,0,1,101,0,6,101,0,1,131,0,0,131,0,1,23,71,72,100,0,5,83],
  co_consts: ["CODEOBJ: Functions_one", "CODEOBJ: Functions_two", "CODEOBJ: Functions_add", "CODEOBJ: Functions_inc", "CODEOBJ: Functions_four", "None"],
  co_names: ["one", "two", "add", "three", "inc", "four", "str"],
  co_locals: [],
  toString: function() { return "CodeObject:Functions"}
};

var Functions_one = {
  co_name: "one",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,1,83],
  co_consts: ["None", 1],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:Functions_one"}
};

var Functions_two = {
  co_name: "two",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [100,0,1,83],
  co_consts: ["None", 2],
  co_names: [],
  co_locals: [],
  toString: function() { return "CodeObject:Functions_two"}
};

var Functions_add = {
  co_name: "add",
  co_argcount: 2,
  co_nlocals: 2,
  co_varnames: ["left", "right"],
  co_code: [124,0,0,124,0,1,23,83],
  co_consts: ["None"],
  co_names: ["left", "right"],
  co_locals: [],
  toString: function() { return "CodeObject:Functions_add"}
};

var Functions_inc = {
  co_name: "inc",
  co_argcount: 1,
  co_nlocals: 1,
  co_varnames: ["value"],
  co_code: [124,0,0,116,0,1,131,0,0,23,83],
  co_consts: ["None"],
  co_names: ["value", "one"],
  co_locals: [],
  toString: function() { return "CodeObject:Functions_inc"}
};

var Functions_four = {
  co_name: "four",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,116,0,1,131,0,1,83],
  co_consts: ["None"],
  co_names: ["inc", "three"],
  co_locals: [],
  toString: function() { return "CodeObject:Functions_four"}
};

