from string import join

class CompareStrings:
    version = 2.0
    operations = 10 * 5
    rounds = 400 #200#000

    def test(self):
        # Make sure the strings are *not* interned
        s = join(map(str,range(10)))
        t = join(map(str,range(10))) + "abc"

        for i in xrange(self.rounds):
            t < s
            t > s
            t == s
            t > s
            t < s

            t < s
            t > s
            t == s
            t > s
            t < s

            t < s
            t > s
            t == s
            t > s
            t < s

            t < s
            t > s
            t == s
            t > s
            t < s

            t < s
            t > s
            t == s
            t > s
            t < s

            t < s
            t > s
            t == s
            t > s
            t < s

            t < s
            t > s
            t == s
            t > s
            t < s

            t < s
            t > s
            t == s
            t > s
            t < s

            t < s
            t > s
            t == s
            t > s
            t < s

            t < s
            t > s
            t == s
            t > s
            t < s

CompareStrings().test()

print 42