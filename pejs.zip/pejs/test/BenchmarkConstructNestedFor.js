//This file was automatically created with compiler.py

var BenchmarkConstructNestedFor = {
  co_name: "?",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: ["NestedForLoops"],
  co_code: [100,0,0,102,0,0,100,0,1,132,0,0,131,0,0,89,90,0,0,101,0,0,131,0,0,105,0,1,131,0,0,1,100,0,2,71,72,100,0,3,83],
  co_consts: ["NestedForLoops", "CODEOBJ: BenchmarkConstructNestedFor_NestedForLoops", 42, "None"],
  co_names: ["NestedForLoops", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkConstructNestedFor"}
};

var BenchmarkConstructNestedFor_NestedForLoops = {
  co_name: "NestedForLoops",
  co_argcount: 0,
  co_nlocals: 0,
  co_varnames: [],
  co_code: [116,0,0,90,0,1,100,0,1,90,0,2,100,0,2,100,0,3,20,100,0,4,20,90,0,3,100,0,5,90,0,4,100,0,6,132,0,0,90,0,5,82,83],
  co_consts: ["None", 2.0, 1000, 10, 5, 1, "CODEOBJ: BenchmarkConstructNestedFor_NestedForLoops_test"],
  co_names: ["__name__", "__module__", "version", "operations", "rounds", "test"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkConstructNestedFor_NestedForLoops"}
};

var BenchmarkConstructNestedFor_NestedForLoops_test = {
  co_name: "test",
  co_argcount: 1,
  co_nlocals: 7,
  co_varnames: ["self", "i", "j", "l2", "l3", "l1", "k"],
  co_code: [116,0,0,100,0,1,131,0,1,125,0,5,116,0,0,100,0,2,131,0,1,125,0,3,116,0,0,100,0,3,131,0,1,125,0,4,120,0,74,116,0,4,124,0,0,105,0,6,131,0,1,68,93,0,57,125,0,1,120,0,48,124,0,5,68,93,0,40,125,0,1,120,0,31,124,0,3,68,93,0,23,125,0,2,120,0,14,124,0,4,68,93,0,6,125,0,6,113,0,91,87,113,0,78,87,113,0,65,87,113,0,52,87,100,0,0,83],
  co_consts: ["None", 1000, 10, 5],
  co_names: ["range", "l1", "l2", "l3", "xrange", "self", "rounds", "i", "j", "k"],
  co_locals: [],
  toString: function() { return "CodeObject:BenchmarkConstructNestedFor_NestedForLoops_test"}
};

